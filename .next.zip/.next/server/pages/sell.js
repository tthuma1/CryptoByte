module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("YkDJ");


/***/ }),

/***/ "5Yp1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__("FfxO");

// EXTERNAL MODULE: ./routes.js
var routes = __webpack_require__("8cHP");

// EXTERNAL MODULE: ./ethereum/web3.js
var web3 = __webpack_require__("oZBQ");

// EXTERNAL MODULE: ./ethereum/cryptoByte721.js + 1 modules
var cryptoByte721 = __webpack_require__("igWR");

// CONCATENATED MODULE: ./components/Header.js
var __jsx = external_react_default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






let currentAccount;

class Header_Header extends external_react_default.a.Component {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      isAdmin: 'none',
      visibleFull: 'hidden',
      pausedMounted: false,
      hasMounted: false
    });
  }

  async componentDidMount() {
    currentAccount = (await web3["a" /* default */].eth.getAccounts())[0];

    if ((await web3["a" /* default */].eth.net.getNetworkType()) === "main" && typeof currentAccount !== 'undefined') {
      const isMinter = await cryptoByte721["a" /* default */].methods.isMinter(currentAccount).call();

      if (isMinter) {
        this.setState({
          isAdmin: 'flex'
        });
      }
    }

    const interval = setInterval(() => {
      if (!this.state.hasMounted && this.props.mounted == true) {
        this.props.updateState(true);
        this.setState({
          visibleFull: 'visible',
          hasMounted: true
        });
      }

      if (this.props.mounted == false) {
        this.props.updateState(false);
        this.setState({
          visibleFull: 'hidden'
        });
      }
    }, 500);
  }

  hideAll() {
    this.setState({
      visibleFull: 'hidden'
    });
    this.props.updateState(false);
  }

  render() {
    return __jsx("div", null, __jsx(external_semantic_ui_react_["Menu"], {
      stackable: true,
      inverted: true,
      fixed: "top",
      id: "header",
      style: {
        visibility: this.state.visibleFull
      }
    }, __jsx(routes["Link"], {
      href: "/"
    }, __jsx("a", {
      className: "item"
    }, __jsx("img", {
      src: "/static/favicon2.png"
    }))), __jsx(routes["Link"], {
      href: "/"
    }, __jsx("a", {
      className: "item"
    }, "Home")), __jsx(external_semantic_ui_react_["Dropdown"], {
      item: true,
      text: "Collectible Tokens"
    }, __jsx(external_semantic_ui_react_["Dropdown"].Menu, null, __jsx(routes["Link"], {
      href: "/tokens"
    }, __jsx("a", {
      className: "item",
      onClick: () => {
        if (!(location.pathname == '/tokens')) {
          this.hideAll();
        } else {
          this.hideAll();
          location.reload();
        }
      }
    }, "All Tokens")), __jsx(routes["Link"], {
      href: `/tokens/${currentAccount}`
    }, __jsx("a", {
      className: "item",
      onClick: () => {
        this.hideAll();
      }
    }, "My Tokens")), __jsx(routes["Link"], {
      href: "/create_tokens"
    }, __jsx("a", {
      className: "item"
    }, "Create New Tokens")))), __jsx(routes["Link"], {
      href: "/media"
    }, __jsx("a", {
      className: "item"
    }, "Media")), __jsx(external_semantic_ui_react_["Menu"].Menu, {
      position: "right",
      style: {
        backgroundColor: '#444444',
        display: this.state.isAdmin
      }
    }, __jsx(routes["Link"], {
      route: "/"
    }, __jsx("a", {
      className: "item"
    }, "Admin Page")))));
  }

}

/* harmony default export */ var components_Header = (Header_Header);
// CONCATENATED MODULE: ./components/Footer.js

var Footer_jsx = external_react_default.a.createElement;



class Footer_Footer extends external_react_["Component"] {
  render() {
    return Footer_jsx(external_semantic_ui_react_["Grid"], {
      style: {
        marginTop: '10vh',
        backgroundColor: 'rgba(255,255,255,.05)',
        color: 'white'
      }
    }, Footer_jsx(external_semantic_ui_react_["Grid"].Row, {
      columns: 2
    }, Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "right"
    }, Footer_jsx("span", null, "Contract address:"), ' ', Footer_jsx("a", {
      href: `https://etherscan.io/token/${"0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5"}`,
      target: "_blank"
    }, "0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5")), Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "left"
    }, "Contact us:", ' ', Footer_jsx("a", {
      href: "mailto:info@crypto-byte.com"
    }, "info@crypto-byte.com"))), Footer_jsx(external_semantic_ui_react_["Grid"].Row, {
      columns: 1,
      style: {
        fontSize: '23px'
      }
    }, Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "center"
    }, Footer_jsx("a", {
      href: "https://www.reddit.com/r/crypto_byte/",
      target: "_blank"
    }, Footer_jsx(external_semantic_ui_react_["Icon"], {
      name: "reddit",
      size: "big",
      style: {
        color: '#ccc',
        marginRight: '30px'
      }
    })), Footer_jsx("a", {
      href: "https://twitter.com/crypto_byte721",
      target: "_blank"
    }, Footer_jsx(external_semantic_ui_react_["Icon"], {
      name: "twitter square",
      size: "big",
      style: {
        color: '#ccc',
        marginRight: '30px'
      }
    })), Footer_jsx("a", {
      href: "https://t.me/Crypto_ByteERC721",
      target: "_blank"
    }, Footer_jsx(external_semantic_ui_react_["Icon"], {
      name: "telegram",
      size: "big",
      style: {
        color: '#ccc'
      }
    })))), Footer_jsx(external_semantic_ui_react_["Grid"].Row, null, Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "center"
    }, Footer_jsx("p", {
      style: {
        color: '#ccc'
      }
    }, "This website does not collect any cookies."))));
  }

}

/* harmony default export */ var components_Footer = (Footer_Footer);
// CONCATENATED MODULE: ./components/LoadingScreen.js
var LoadingScreen_jsx = external_react_default.a.createElement;


class LoadingScreen_LoadingScreen extends external_react_default.a.Component {
  render() {
    return LoadingScreen_jsx("div", null, LoadingScreen_jsx("style", null, `
.container {
    width: 100vw;
    height: 100vh;
    position: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
}
.c1 {
    background: linear-gradient(to bottom, #bdc3c7, #2c3e50);
}
.loader1 {
    height: 100px;
    width: 100px;
}
.l1 {
    height: 80px;
    width: 80px;
    border-radius: 50%;
    border: 10px solid transparent;
    border-top: 10px solid white;
    border-bottom: 10px solid white;
    position: relative;
    animation: spin1 2s infinite;
    -webkit-animation: spin1 2s infinite;
}
.l2 {
    height: 50px;
    width: 50px;
    border-radius: 50%;
    border: 10px solid transparent;
    border-left: 10px solid white;
    border-right: 10px solid white;
    position: relative;
    bottom: 65px;
    left: 15px;
    animation: spin2 2s infinite;
    -webkit-animation: spin2 2s infinite;
}
@keyframes spin1 {
    50% {
        transform: rotate(360deg);
    }
}
@keyframes spin2 {
    50% {
        transform: rotate(-360deg);
    }
}
@-webkit-keyframes spin1 {
    50% {
        -webkit-transform: rotate(360deg);
    }
}
@-webkit-keyframes spin2 {
    50% {
        -webkit-transform: rotate(-360deg);
    }
}
                `), LoadingScreen_jsx("div", {
      className: "container c1"
    }, LoadingScreen_jsx("div", {
      className: "loader1"
    }, LoadingScreen_jsx("div", {
      className: "l1"
    }), LoadingScreen_jsx("div", {
      className: "l2"
    })), LoadingScreen_jsx("div", {
      className: "container"
    }, LoadingScreen_jsx("p", {
      style: {
        color: 'white',
        position: 'relative',
        top: '70px'
      }
    }, "Reading smart contract, please wait ..."))));
  }

}

/* harmony default export */ var components_LoadingScreen = (LoadingScreen_LoadingScreen);
// CONCATENATED MODULE: ./components/Layout.js
var Layout_jsx = external_react_default.a.createElement;

function Layout_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







class Layout_Layout extends external_react_default.a.Component {
  constructor(props) {
    super(props);

    Layout_defineProperty(this, "updateState", isMounted => {
      if (isMounted) {
        this.setState({
          allMounted: true
        });
      } else {
        this.setState({
          allMounted: false
        });
      }
    });

    this.state = {
      allMounted: false
    };

    try {
      ethereum.on('accountsChanged', _accounts => {
        location.reload();
        ethereum.on('chainChanged', chainId => {
          location.reload();
        });
      });
    } catch {}
  }

  render() {
    return Layout_jsx("div", null, Layout_jsx(head_default.a, null, Layout_jsx("link", {
      rel: "stylesheet",
      href: "//cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css"
    }), Layout_jsx("meta", {
      name: "viewport",
      content: "width=1024"
    }), Layout_jsx("link", {
      rel: "shortcut icon",
      type: "image/png",
      href: "/static/favicon.png"
    }), Layout_jsx("meta", {
      charSet: "UTF-8"
    }), Layout_jsx("meta", {
      name: "keywords",
      content: "Crypto, Byte, Collectible, Ethereum, Ether, ETH, ERC721, token, tokens"
    }), Layout_jsx("title", null, "Crypto Byte Collectible"), Layout_jsx("meta", {
      name: "description",
      content: "Official website of Crypto Byte Collectible tokens - your unique collectible ERC721 tokens. Interact with a smart contract deployed on the Ethereum blockchain."
    }), Layout_jsx("meta", {
      name: "robots",
      content: "index, follow"
    })), Layout_jsx("style", null, `
html, body {
  background-color: #03080c;
  scroll-behavior: smooth;
}
          `), !this.props.isHome ? Layout_jsx("style", null, `
html, body {
  background: linear-gradient(to top, #111, #333);
  background-attachment: fixed;
}
          `) : '', !this.state.allMounted && Layout_jsx(components_LoadingScreen, null), Layout_jsx("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh'
      }
    }, Layout_jsx(components_Header, {
      mounted: this.props.mounted,
      updateState: this.updateState
    }), Layout_jsx("div", {
      style: {
        flex: 1
      }
    }, this.state.allMounted && this.props.children), this.state.allMounted && Layout_jsx(components_Footer, null)));
  }

}

/* harmony default export */ var components_Layout = __webpack_exports__["a"] = (Layout_Layout);

/***/ }),

/***/ "8cHP":
/***/ (function(module, exports, __webpack_require__) {

const routes = module.exports = __webpack_require__("90Kz")();

routes.add('/gift/:id', '/gift').add('/sell/:id', '/sell').add('/token/:id', '/token').add('/tokens/:owner', '/tokens/owner');

/***/ }),

/***/ "90Kz":
/***/ (function(module, exports) {

module.exports = require("next-routes");

/***/ }),

/***/ "FfxO":
/***/ (function(module, exports) {

module.exports = require("semantic-ui-react");

/***/ }),

/***/ "MDWq":
/***/ (function(module, exports) {

module.exports = require("web3");

/***/ }),

/***/ "YkDJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5Yp1");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("FfxO");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("igWR");
/* harmony import */ var _components_MMPrompt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("yo71");
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("oZBQ");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("8cHP");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_7__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









let currentAccount, headerEl;

class SellToken extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      mounted: false,
      headerHeight: 0,
      newPrice: '',
      newPriceErr: false,
      msgErr: false,
      loading: false,
      success: false,
      currentPrice: 0,
      saleLoading: false
    });

    _defineProperty(this, "removeSale", async event => {
      event.preventDefault();
      this.setState({
        saleLoading: true,
        msgErr: ''
      });

      try {
        await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"].methods.setTokenPrice(this.props.id, 0).send({
          from: currentAccount
        });
        this.setState({
          saleLoading: false,
          success: true
        });
        _routes__WEBPACK_IMPORTED_MODULE_6__["Router"].pushRoute(`/token/${this.props.id}`);
      } catch (err) {
        this.setState({
          saleLoading: false,
          msgErr: "You aren't logged in your MetaMask account."
        });
      }

      this.setState({
        currentPrice: await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"].methods.getTokenPrice(this.props.id).call()
      });
    });

    _defineProperty(this, "onSubmit", async event => {
      event.preventDefault();
      this.setState({
        loading: true,
        msgErr: ''
      });

      try {
        if (this.state.newPriceErr || this.state.newPrice === '') {
          throw {
            message: 'Invalid token price.'
          };
        }

        await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"].methods.setTokenPrice(this.props.id, _ethereum_web3__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"].utils.toWei(this.state.newPrice, 'ether')).send({
          from: currentAccount
        });
        this.setState({
          loading: false,
          success: true
        });
        _routes__WEBPACK_IMPORTED_MODULE_6__["Router"].pushRoute(`/token/${this.props.id}`);
      } catch (err) {
        this.setState({
          loading: false,
          msgErr: err.message == 'Invalid token price.' ? err.message : "You aren't logged in your MetaMask account."
        });
      }
    });
  }

  static async getInitialProps({
    query
  }) {
    return {
      id: query.id
    };
  }

  async componentDidMount() {
    currentAccount = (await _ethereum_web3__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"].eth.getAccounts())[0];
    headerEl = document.getElementById('header');
    const headerVisible = setInterval(() => {
      if (headerEl.style.visibility === 'visible') {
        this.setState({
          headerHeight: headerEl.clientHeight
        });
        clearInterval(headerVisible);
      }
    }, 100);
    this.setState({
      currentPrice: await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"].methods.getTokenPrice(this.props.id).call()
    });
    this.setState({
      mounted: true
    });
  }

  render() {
    return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], {
      mounted: this.state.mounted
    }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_7___default.a, null, __jsx("title", null, "Crypto Byte Collectible - Sell Tokens"), __jsx("meta", {
      name: "description",
      content: "Put your Crypto Byte Collectible tokens up for sale in exchange for Ether (ETH)."
    }), __jsx("meta", {
      name: "robots",
      content: "index, follow"
    })), __jsx(_components_MMPrompt__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"], null), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Container"], {
      style: {
        marginTop: this.state.headerHeight + 20
      }
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Header"], {
      as: "h3",
      inverted: true,
      dividing: true,
      textAlign: "center"
    }, "You can change the price of your ERC721 tokens with the form below."), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"], {
      inverted: true,
      onSubmit: this.onSubmit
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
      widths: "equal"
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Input, {
      label: "Token price",
      error: this.state.newPriceErr
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"], {
      placeholder: "123",
      value: this.state.newPrice,
      label: "ETH",
      labelPosition: "right",
      onChange: event => {
        this.setState({
          newPrice: event.target.value
        });

        if ((isNaN(event.target.value) || parseFloat(event.target.value) < 0 || event.target.value.substring(0, 2) === '0x') && !(event.target.value === '')) {
          this.setState({
            newPriceErr: {
              content: 'The price must be a positive number.'
            }
          });
        } else {
          this.setState({
            newPriceErr: false
          });
        }
      }
    }))), this.state.newPrice && !this.state.newPriceErr && __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
      info: true
    }, __jsx("p", null, "This is going to change the price of your ERC721 token with", ' ', __jsx("b", null, "ID ", this.props.id), " to ", __jsx("b", null, this.state.newPrice, " ETH"), ".", __jsx("br", null))), this.state.msgErr && __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
      negative: true,
      compact: true
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"].Header, null, "Something went wrong!"), this.state.msgErr), __jsx("br", null)), this.state.success && __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
      positive: true,
      compact: true
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"].Header, null, "Transaction complete!"), "The transaction was completed successfully."), __jsx("br", null)), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
      type: "submit",
      loading: this.state.loading,
      disabled: this.state.loading
    }, "Submit"), Number(this.state.currentPrice) ? __jsx("div", null, __jsx("p", {
      style: {
        color: 'white',
        marginBottom: '5px',
        marginTop: '40px'
      }
    }, "This token is currently up for sale for", ' ', _ethereum_web3__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"].utils.fromWei(this.state.currentPrice, 'ether'), " ETH. To remove it from sale, click the button bellow."), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
      color: "red",
      onClick: this.removeSale,
      loading: this.state.saleLoading,
      disabled: this.state.saleLoading
    }, "Remove from sale")) : '')));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (SellToken);

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "igWR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./ethereum/web3.js
var web3 = __webpack_require__("oZBQ");

// CONCATENATED MODULE: ./ethereum/abi721.js
const abi = [{
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'addMinter',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  inputs: [{
    internalType: 'string',
    name: 'name',
    type: 'string'
  }, {
    internalType: 'string',
    name: 'symbol',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'constructor'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'address',
    name: 'approved',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'Approval',
  type: 'event'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'address',
    name: 'operator',
    type: 'address'
  }, {
    indexed: false,
    internalType: 'bool',
    name: 'approved',
    type: 'bool'
  }],
  name: 'ApprovalForAll',
  type: 'event'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'approve',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'buyToken',
  outputs: [],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }],
  name: 'mint',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'MinterAdded',
  type: 'event'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'MinterRemoved',
  type: 'event'
}, {
  constant: false,
  inputs: [],
  name: 'renounceMinter',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }],
  name: 'safeMint',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'bytes',
    name: '_data',
    type: 'bytes'
  }],
  name: 'safeMint',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'safeTransferFrom',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }, {
    internalType: 'bytes',
    name: '_data',
    type: 'bytes'
  }],
  name: 'safeTransferFrom',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'bool',
    name: 'approved',
    type: 'bool'
  }],
  name: 'setApprovalForAll',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'uint256',
    name: 'newMintPrice',
    type: 'uint256'
  }],
  name: 'setMintPrice',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }, {
    internalType: 'uint256',
    name: 'newPrice',
    type: 'uint256'
  }],
  name: 'setTokenPrice',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'Transfer',
  type: 'event'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'transferFrom',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address payable',
    name: 'to',
    type: 'address'
  }],
  name: 'withdraw',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }],
  name: 'balanceOf',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'baseURI',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'getApproved',
  outputs: [{
    internalType: 'address',
    name: '',
    type: 'address'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'getMintPrice',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'getTokenPrice',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'operator',
    type: 'address'
  }],
  name: 'isApprovedForAll',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'isMinter',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'name',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'ownerOf',
  outputs: [{
    internalType: 'address',
    name: '',
    type: 'address'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'bytes4',
    name: 'interfaceId',
    type: 'bytes4'
  }],
  name: 'supportsInterface',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'symbol',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'index',
    type: 'uint256'
  }],
  name: 'tokenByIndex',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'index',
    type: 'uint256'
  }],
  name: 'tokenOfOwnerByIndex',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }],
  name: 'tokensOfOwner',
  outputs: [{
    internalType: 'uint256[]',
    name: '',
    type: 'uint256[]'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'tokenURI',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'totalSupply',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}];
/* harmony default export */ var abi721 = (abi);
// CONCATENATED MODULE: ./ethereum/cryptoByte721.js


const instance = new web3["a" /* default */].eth.Contract(abi721, "0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5");
/* harmony default export */ var cryptoByte721 = __webpack_exports__["a"] = (instance);

/***/ }),

/***/ "oZBQ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("MDWq");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_0__);

let web3;

if (false) {} else {
  const provider = new web3__WEBPACK_IMPORTED_MODULE_0___default.a.providers.HttpProvider("https://mainnet.infura.io/v3/b459ad4f809e4892968c27f7b909cb2b");
  web3 = new web3__WEBPACK_IMPORTED_MODULE_0___default.a(provider);
}

/* harmony default export */ __webpack_exports__["a"] = (web3);

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "yo71":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("FfxO");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("8cHP");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("oZBQ");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





let isMetaMask;

class MMPrompt extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      modalOpen: true,
      visibility: 'hidden'
    });

    _defineProperty(this, "handleClose", () => {
      this.setState({
        modalOpen: false
      });
    });

    _defineProperty(this, "handleOpen", () => {
      this.setState({
        modalOpen: true
      });
    });
  }

  async componentDidMount() {
    isMetaMask = await _ethereum_web3__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"].currentProvider.isMetaMask;

    if (isMetaMask || this.props.visible === false) {
      this.handleClose();
    }
  }

  render() {
    return __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"], {
      size: "small",
      open: this.state.modalOpen,
      trigger: this.props.trigger,
      onClose: this.handleClose,
      onOpen: this.handleOpen
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Header"], {
      as: "h3"
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
      src: "/static/images/download-metamask-dark.png",
      as: "a",
      href: "https://metamask.io/",
      target: "_blank"
    }), "Use MetaMask to interact with the smart contract"), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"].Content, {
      image: true,
      scrolling: true
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
      size: "medium",
      src: "/static/images/metamask-network.png"
    }), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"].Description, null, __jsx("p", null, "To interact with the Crypto Byte Collectible smart contract, you'll need to have the", ' ', __jsx(_routes__WEBPACK_IMPORTED_MODULE_2__["Link"], {
      route: "https://metamask.io/"
    }, __jsx("a", {
      target: "_blank"
    }, "MetaMask")), ' ', "browser extension.", __jsx("br", null), "Make sure you're connected to the Main Ethereum Network."))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"].Actions, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      color: "green",
      inverted: true,
      onClick: this.handleClose
    }, "Close")));
  }

}

/* harmony default export */ __webpack_exports__["a"] = (MMPrompt);

/***/ })

/******/ });