module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/arD":
/***/ (function(module, exports) {

module.exports = require("jdenticon");

/***/ }),

/***/ "5Yp1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__("FfxO");

// EXTERNAL MODULE: ./routes.js
var routes = __webpack_require__("8cHP");

// EXTERNAL MODULE: ./ethereum/web3.js
var web3 = __webpack_require__("oZBQ");

// EXTERNAL MODULE: ./ethereum/cryptoByte721.js + 1 modules
var cryptoByte721 = __webpack_require__("igWR");

// CONCATENATED MODULE: ./components/Header.js
var __jsx = external_react_default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






let currentAccount;

class Header_Header extends external_react_default.a.Component {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      isAdmin: 'none',
      visibleFull: 'hidden',
      pausedMounted: false,
      hasMounted: false
    });
  }

  async componentDidMount() {
    currentAccount = (await web3["a" /* default */].eth.getAccounts())[0];

    if ((await web3["a" /* default */].eth.net.getNetworkType()) === "main" && typeof currentAccount !== 'undefined') {
      const isMinter = await cryptoByte721["a" /* default */].methods.isMinter(currentAccount).call();

      if (isMinter) {
        this.setState({
          isAdmin: 'flex'
        });
      }
    }

    const interval = setInterval(() => {
      if (!this.state.hasMounted && this.props.mounted == true) {
        this.props.updateState(true);
        this.setState({
          visibleFull: 'visible',
          hasMounted: true
        });
      }

      if (this.props.mounted == false) {
        this.props.updateState(false);
        this.setState({
          visibleFull: 'hidden'
        });
      }
    }, 500);
  }

  hideAll() {
    this.setState({
      visibleFull: 'hidden'
    });
    this.props.updateState(false);
  }

  render() {
    return __jsx("div", null, __jsx(external_semantic_ui_react_["Menu"], {
      stackable: true,
      inverted: true,
      fixed: "top",
      id: "header",
      style: {
        visibility: this.state.visibleFull
      }
    }, __jsx(routes["Link"], {
      href: "/"
    }, __jsx("a", {
      className: "item"
    }, __jsx("img", {
      src: "/static/favicon2.png"
    }))), __jsx(routes["Link"], {
      href: "/"
    }, __jsx("a", {
      className: "item"
    }, "Home")), __jsx(external_semantic_ui_react_["Dropdown"], {
      item: true,
      text: "Collectible Tokens"
    }, __jsx(external_semantic_ui_react_["Dropdown"].Menu, null, __jsx(routes["Link"], {
      href: "/tokens"
    }, __jsx("a", {
      className: "item",
      onClick: () => {
        if (!(location.pathname == '/tokens')) {
          this.hideAll();
        } else {
          this.hideAll();
          location.reload();
        }
      }
    }, "All Tokens")), __jsx(routes["Link"], {
      href: `/tokens/${currentAccount}`
    }, __jsx("a", {
      className: "item",
      onClick: () => {
        this.hideAll();
      }
    }, "My Tokens")), __jsx(routes["Link"], {
      href: "/create_tokens"
    }, __jsx("a", {
      className: "item"
    }, "Create New Tokens")))), __jsx(routes["Link"], {
      href: "/media"
    }, __jsx("a", {
      className: "item"
    }, "Media")), __jsx(external_semantic_ui_react_["Menu"].Menu, {
      position: "right",
      style: {
        backgroundColor: '#444444',
        display: this.state.isAdmin
      }
    }, __jsx(routes["Link"], {
      route: "/"
    }, __jsx("a", {
      className: "item"
    }, "Admin Page")))));
  }

}

/* harmony default export */ var components_Header = (Header_Header);
// CONCATENATED MODULE: ./components/Footer.js

var Footer_jsx = external_react_default.a.createElement;



class Footer_Footer extends external_react_["Component"] {
  render() {
    return Footer_jsx(external_semantic_ui_react_["Grid"], {
      style: {
        marginTop: '10vh',
        backgroundColor: 'rgba(255,255,255,.05)',
        color: 'white'
      }
    }, Footer_jsx(external_semantic_ui_react_["Grid"].Row, {
      columns: 2
    }, Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "right"
    }, Footer_jsx("span", null, "Contract address:"), ' ', Footer_jsx("a", {
      href: `https://etherscan.io/token/${"0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5"}`,
      target: "_blank"
    }, "0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5")), Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "left"
    }, "Contact us:", ' ', Footer_jsx("a", {
      href: "mailto:info@crypto-byte.com"
    }, "info@crypto-byte.com"))), Footer_jsx(external_semantic_ui_react_["Grid"].Row, {
      columns: 1,
      style: {
        fontSize: '23px'
      }
    }, Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "center"
    }, Footer_jsx("a", {
      href: "https://www.reddit.com/r/crypto_byte/",
      target: "_blank"
    }, Footer_jsx(external_semantic_ui_react_["Icon"], {
      name: "reddit",
      size: "big",
      style: {
        color: '#ccc',
        marginRight: '30px'
      }
    })), Footer_jsx("a", {
      href: "https://twitter.com/crypto_byte721",
      target: "_blank"
    }, Footer_jsx(external_semantic_ui_react_["Icon"], {
      name: "twitter square",
      size: "big",
      style: {
        color: '#ccc',
        marginRight: '30px'
      }
    })), Footer_jsx("a", {
      href: "https://t.me/Crypto_ByteERC721",
      target: "_blank"
    }, Footer_jsx(external_semantic_ui_react_["Icon"], {
      name: "telegram",
      size: "big",
      style: {
        color: '#ccc'
      }
    })))), Footer_jsx(external_semantic_ui_react_["Grid"].Row, null, Footer_jsx(external_semantic_ui_react_["Grid"].Column, {
      textAlign: "center"
    }, Footer_jsx("p", {
      style: {
        color: '#ccc'
      }
    }, "This website does not collect any cookies."))));
  }

}

/* harmony default export */ var components_Footer = (Footer_Footer);
// CONCATENATED MODULE: ./components/LoadingScreen.js
var LoadingScreen_jsx = external_react_default.a.createElement;


class LoadingScreen_LoadingScreen extends external_react_default.a.Component {
  render() {
    return LoadingScreen_jsx("div", null, LoadingScreen_jsx("style", null, `
.container {
    width: 100vw;
    height: 100vh;
    position: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
}
.c1 {
    background: linear-gradient(to bottom, #bdc3c7, #2c3e50);
}
.loader1 {
    height: 100px;
    width: 100px;
}
.l1 {
    height: 80px;
    width: 80px;
    border-radius: 50%;
    border: 10px solid transparent;
    border-top: 10px solid white;
    border-bottom: 10px solid white;
    position: relative;
    animation: spin1 2s infinite;
    -webkit-animation: spin1 2s infinite;
}
.l2 {
    height: 50px;
    width: 50px;
    border-radius: 50%;
    border: 10px solid transparent;
    border-left: 10px solid white;
    border-right: 10px solid white;
    position: relative;
    bottom: 65px;
    left: 15px;
    animation: spin2 2s infinite;
    -webkit-animation: spin2 2s infinite;
}
@keyframes spin1 {
    50% {
        transform: rotate(360deg);
    }
}
@keyframes spin2 {
    50% {
        transform: rotate(-360deg);
    }
}
@-webkit-keyframes spin1 {
    50% {
        -webkit-transform: rotate(360deg);
    }
}
@-webkit-keyframes spin2 {
    50% {
        -webkit-transform: rotate(-360deg);
    }
}
                `), LoadingScreen_jsx("div", {
      className: "container c1"
    }, LoadingScreen_jsx("div", {
      className: "loader1"
    }, LoadingScreen_jsx("div", {
      className: "l1"
    }), LoadingScreen_jsx("div", {
      className: "l2"
    })), LoadingScreen_jsx("div", {
      className: "container"
    }, LoadingScreen_jsx("p", {
      style: {
        color: 'white',
        position: 'relative',
        top: '70px'
      }
    }, "Reading smart contract, please wait ..."))));
  }

}

/* harmony default export */ var components_LoadingScreen = (LoadingScreen_LoadingScreen);
// CONCATENATED MODULE: ./components/Layout.js
var Layout_jsx = external_react_default.a.createElement;

function Layout_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







class Layout_Layout extends external_react_default.a.Component {
  constructor(props) {
    super(props);

    Layout_defineProperty(this, "updateState", isMounted => {
      if (isMounted) {
        this.setState({
          allMounted: true
        });
      } else {
        this.setState({
          allMounted: false
        });
      }
    });

    this.state = {
      allMounted: false
    };

    try {
      ethereum.on('accountsChanged', _accounts => {
        location.reload();
        ethereum.on('chainChanged', chainId => {
          location.reload();
        });
      });
    } catch {}
  }

  render() {
    return Layout_jsx("div", null, Layout_jsx(head_default.a, null, Layout_jsx("link", {
      rel: "stylesheet",
      href: "//cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css"
    }), Layout_jsx("meta", {
      name: "viewport",
      content: "width=1024"
    }), Layout_jsx("link", {
      rel: "shortcut icon",
      type: "image/png",
      href: "/static/favicon.png"
    }), Layout_jsx("meta", {
      charSet: "UTF-8"
    }), Layout_jsx("meta", {
      name: "keywords",
      content: "Crypto, Byte, Collectible, Ethereum, Ether, ETH, ERC721, token, tokens"
    }), Layout_jsx("title", null, "Crypto Byte Collectible"), Layout_jsx("meta", {
      name: "description",
      content: "Official website of Crypto Byte Collectible tokens - your unique collectible ERC721 tokens. Interact with a smart contract deployed on the Ethereum blockchain."
    }), Layout_jsx("meta", {
      name: "robots",
      content: "index, follow"
    })), Layout_jsx("style", null, `
html, body {
  background-color: #03080c;
  scroll-behavior: smooth;
}
          `), !this.props.isHome ? Layout_jsx("style", null, `
html, body {
  background: linear-gradient(to top, #111, #333);
  background-attachment: fixed;
}
          `) : '', !this.state.allMounted && Layout_jsx(components_LoadingScreen, null), Layout_jsx("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh'
      }
    }, Layout_jsx(components_Header, {
      mounted: this.props.mounted,
      updateState: this.updateState
    }), Layout_jsx("div", {
      style: {
        flex: 1
      }
    }, this.state.allMounted && this.props.children), this.state.allMounted && Layout_jsx(components_Footer, null)));
  }

}

/* harmony default export */ var components_Layout = __webpack_exports__["a"] = (Layout_Layout);

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Sf6h");


/***/ }),

/***/ "8cHP":
/***/ (function(module, exports, __webpack_require__) {

const routes = module.exports = __webpack_require__("90Kz")();

routes.add('/gift/:id', '/gift').add('/sell/:id', '/sell').add('/token/:id', '/token').add('/tokens/:owner', '/tokens/owner');

/***/ }),

/***/ "90Kz":
/***/ (function(module, exports) {

module.exports = require("next-routes");

/***/ }),

/***/ "FfxO":
/***/ (function(module, exports) {

module.exports = require("semantic-ui-react");

/***/ }),

/***/ "MDWq":
/***/ (function(module, exports) {

module.exports = require("web3");

/***/ }),

/***/ "Sf6h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5Yp1");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("FfxO");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_MMPrompt__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("yo71");
/* harmony import */ var _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("igWR");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("8cHP");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("oZBQ");
/* harmony import */ var _components_Jdenticon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("qcXG");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_9__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











let currentAccount, headerEl;
let viking = "1,2,3,4,5,6".split(',');
let vikingAmount = viking.length;
let specialEdition = "7,8,9".split(',');
let specialEditionAmount = specialEdition.length;
let specialTokens = viking.concat(specialEdition);
let specialTokensAmount = vikingAmount + specialEditionAmount;

class TokensOfOwner extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      mounted: false,
      headerHeight: 0,
      images: {},
      buyLoading: {},
      jdentHeigth: 220,
      tokenInfo: {}
    });

    _defineProperty(this, "getTokenInfo", async () => {
      let tokenInfo = {};
      let images = {};

      for (let i = 0; i < this.props.balance; i++) {
        let id = Number(this.props.tokens[i]);
        tokenInfo[id] = {};
        tokenInfo[id]['price'] = await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"].methods.getTokenPrice(id).call(); // check if token has image and save it in state

        try {
          await axios__WEBPACK_IMPORTED_MODULE_8___default.a.get(`../static/images/ERC721/${id}_w.jpg`);
          images[id] = true;
        } catch (error) {
          images[id] = false;
        }

        this.setState({
          tokenInfo,
          images
        });
      }
    });

    _defineProperty(this, "buyToken", async event => {
      var id = event.target.name;
      event.preventDefault();
      this.setState(prevState => {
        let buyLoading = Object.assign({}, prevState.buyLoading);
        buyLoading[id] = true;
        return {
          buyLoading
        };
      });

      try {
        await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"].methods.buyToken(id).send({
          from: currentAccount,
          value: this.state.tokenInfo[id]['price']
        });
        _routes__WEBPACK_IMPORTED_MODULE_5__["Router"].replaceRoute(`/tokens/${this.props.owner}`);
      } catch {}

      this.setState(prevState => {
        let buyLoading = Object.assign({}, prevState.buyLoading);
        buyLoading[id] = false;
        return {
          buyLoading
        };
      });
    });

    _defineProperty(this, "updateImage", async (e, {
      calculations
    }) => {
      this.setState({
        jdentHeigth: calculations.height - 50
      });
    });
  }

  static async getInitialProps({
    query
  }) {
    try {
      let owner = _ethereum_web3__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"].utils.toChecksumAddress(query.owner);
      const balance = await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"].methods.balanceOf(owner).call();
      let tokens = [];

      for (let i = 0; i < balance; i++) {
        let token = await _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"].methods.tokenOfOwnerByIndex(owner, i).call();
        tokens.push(token);
      }

      tokens.sort(function (a, b) {
        return a - b;
      });
      return {
        tokens,
        owner,
        balance,
        isValidAccount: true
      };
    } catch {
      return {
        isValidAccount: false
      };
    }
  }

  async componentDidMount() {
    currentAccount = (await _ethereum_web3__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"].eth.getAccounts())[0];
    headerEl = document.getElementById('header');
    const headerVisible = setInterval(() => {
      if (headerEl.style.visibility === 'visible') {
        this.setState({
          transVisible: true,
          headerHeight: headerEl.clientHeight
        });
        clearInterval(headerVisible);
      }
    }, 100);
    this.setState({
      mounted: true
    });
    this.getTokenInfo();
  }

  renderTokens() {
    let items = [];
    let classic = [];

    for (let id = 1; id <= this.props.balance; id++) {
      if (specialTokens.indexOf(String(id)) < 0) {
        classic.push(id);
      }
    }

    items.push(this.makeCards(viking), this.makeCards(specialEdition), this.makeCards(classic));
    return __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"].Group, {
      itemsPerRow: 3
    }, items);
  }

  makeCards(ids) {
    let items = [];

    for (let i = 0; i < ids.length; i++) {
      let id = ids[i];

      if (this.props.tokens.indexOf(String(id)) >= 0) {
        items.push(__jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"], {
          key: id
        }, this.state.tokenInfo[id] ? this.state.images[id] ? id == this.state.images[Object.keys(this.state.images)[0]] ? __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Visibility"], {
          onUpdate: this.updateImage
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Image"], {
          src: `/static/images/ERC721/${id}_w.jpg`,
          wrapped: true
        })) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Image"], {
          src: `/static/images/ERC721/${id}_w.jpg`,
          wrapped: true
        }) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Container"], {
          textAlign: "center",
          style: {
            background: 'rgba(0,0,0,.05)',
            overflow: 'auto',
            paddingTop: '25px',
            paddingBottom: '25px'
          }
        }, __jsx(_components_Jdenticon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
          value: id,
          size: this.state.jdentHeigth
        })) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Placeholder"], {
          fluid: true
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Placeholder"].Image, {
          style: {
            height: this.state.jdentHeigth + 50
          }
        })), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"].Content, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"].Header, null, viking.indexOf(String(id)) >= 0 ? 'Viking Collection #' + id : specialEdition.indexOf(String(id)) >= 0 ? 'Special Edition #' + (id - vikingAmount) : 'CRBC Token #' + (id - specialTokensAmount)), this.state.tokenInfo[id] ? __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"].Description, null, __jsx("b", null, Number(this.state.tokenInfo[id]['price']) ? 'Token price: ' + _ethereum_web3__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"].utils.fromWei(this.state.tokenInfo[id]['price'], 'ether') + ' ETH' : 'Token not for sale')), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"].Meta, {
          style: {
            overflow: 'auto'
          }
        }, "Owner : ", this.props.owner)) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Placeholder"], {
          style: {
            marginTop: '10px'
          }
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Placeholder"].Header, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Placeholder"].Line, {
          length: "very short"
        }), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Placeholder"].Line, {
          length: "medium"
        })))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Card"].Content, {
          extra: true
        }, __jsx(_routes__WEBPACK_IMPORTED_MODULE_5__["Link"], {
          route: `/token/${id}`
        }, __jsx("a", {
          onClick: () => {
            this.setState({
              mounted: false
            });
          }
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], null, "View Details", __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
          name: "chevron circle right"
        })))), this.state.tokenInfo[id] ? Number(this.state.tokenInfo[id]['price']) && this.props.owner != currentAccount ? __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          name: id,
          primary: true,
          onClick: this.buyToken,
          loading: this.state.buyLoading[id],
          disabled: this.state.buyLoading[id],
          style: {
            marginTop: '5px'
          }
        }, "Buy token", __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
          name: "shopping cart right"
        })) : '' : '')));
      }
    }

    return items;
  }

  render() {
    return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], {
      mounted: this.state.mounted
    }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_9___default.a, null, __jsx("title", null, "Crypto Byte Collectible - Your Tokens"), __jsx("meta", {
      name: "description",
      content: "View and manage all Crypto Byte Collectible tokens that you own."
    }), __jsx("meta", {
      name: "robots",
      content: "index, follow"
    })), __jsx(_components_MMPrompt__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], null), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Container"], {
      textAlign: "center",
      style: {
        marginTop: this.state.headerHeight + 20
      }
    }, this.props.isValidAccount ? __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Header"], {
      as: "h2",
      inverted: true,
      dividing: true
    }, this.props.owner, ' ', __jsx("span", {
      style: {
        color: '#E8E8E8'
      }
    }, "owns"), ' ', this.props.balance, ' ', __jsx("span", {
      style: {
        color: '#E8E8E8'
      }
    }, "token", this.props.balance != 1 ? 's' : '', ".")), this.renderTokens()) : __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
      negative: true
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"].Header, null, "Oops, something went wrong!"), __jsx("p", null, "Looks like the account you're searching for doesn't exist.")), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Segment"], {
      inverted: true,
      clearing: true
    }, "If you're seeing this message, you most likely aren't logged in your", ' ', __jsx(_routes__WEBPACK_IMPORTED_MODULE_5__["Link"], {
      route: "https://metamask.io/"
    }, __jsx("a", {
      target: "_blank"
    }, " MetaMask")), ' ', "account.", __jsx("br", null), "To view MetaMask use instructions, click on this button.", ' ', __jsx(_components_MMPrompt__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
      trigger: __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        size: "small",
        compact: true
      }, "View Instructions"),
      visible: false
    })))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (TokensOfOwner);

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "igWR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./ethereum/web3.js
var web3 = __webpack_require__("oZBQ");

// CONCATENATED MODULE: ./ethereum/abi721.js
const abi = [{
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'addMinter',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  inputs: [{
    internalType: 'string',
    name: 'name',
    type: 'string'
  }, {
    internalType: 'string',
    name: 'symbol',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'constructor'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'address',
    name: 'approved',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'Approval',
  type: 'event'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'address',
    name: 'operator',
    type: 'address'
  }, {
    indexed: false,
    internalType: 'bool',
    name: 'approved',
    type: 'bool'
  }],
  name: 'ApprovalForAll',
  type: 'event'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'approve',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'buyToken',
  outputs: [],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }],
  name: 'mint',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'MinterAdded',
  type: 'event'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'MinterRemoved',
  type: 'event'
}, {
  constant: false,
  inputs: [],
  name: 'renounceMinter',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }],
  name: 'safeMint',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'bytes',
    name: '_data',
    type: 'bytes'
  }],
  name: 'safeMint',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: true,
  stateMutability: 'payable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'safeTransferFrom',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }, {
    internalType: 'bytes',
    name: '_data',
    type: 'bytes'
  }],
  name: 'safeTransferFrom',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'bool',
    name: 'approved',
    type: 'bool'
  }],
  name: 'setApprovalForAll',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'uint256',
    name: 'newMintPrice',
    type: 'uint256'
  }],
  name: 'setMintPrice',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }, {
    internalType: 'uint256',
    name: 'newPrice',
    type: 'uint256'
  }],
  name: 'setTokenPrice',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  anonymous: false,
  inputs: [{
    indexed: true,
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    indexed: true,
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'Transfer',
  type: 'event'
}, {
  constant: false,
  inputs: [{
    internalType: 'address',
    name: 'from',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'to',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'transferFrom',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: false,
  inputs: [{
    internalType: 'address payable',
    name: 'to',
    type: 'address'
  }],
  name: 'withdraw',
  outputs: [],
  payable: false,
  stateMutability: 'nonpayable',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }],
  name: 'balanceOf',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'baseURI',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'getApproved',
  outputs: [{
    internalType: 'address',
    name: '',
    type: 'address'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'getMintPrice',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'getTokenPrice',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    internalType: 'address',
    name: 'operator',
    type: 'address'
  }],
  name: 'isApprovedForAll',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'account',
    type: 'address'
  }],
  name: 'isMinter',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'name',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'ownerOf',
  outputs: [{
    internalType: 'address',
    name: '',
    type: 'address'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'bytes4',
    name: 'interfaceId',
    type: 'bytes4'
  }],
  name: 'supportsInterface',
  outputs: [{
    internalType: 'bool',
    name: '',
    type: 'bool'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'symbol',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'index',
    type: 'uint256'
  }],
  name: 'tokenByIndex',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }, {
    internalType: 'uint256',
    name: 'index',
    type: 'uint256'
  }],
  name: 'tokenOfOwnerByIndex',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'address',
    name: 'owner',
    type: 'address'
  }],
  name: 'tokensOfOwner',
  outputs: [{
    internalType: 'uint256[]',
    name: '',
    type: 'uint256[]'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [{
    internalType: 'uint256',
    name: 'tokenId',
    type: 'uint256'
  }],
  name: 'tokenURI',
  outputs: [{
    internalType: 'string',
    name: '',
    type: 'string'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}, {
  constant: true,
  inputs: [],
  name: 'totalSupply',
  outputs: [{
    internalType: 'uint256',
    name: '',
    type: 'uint256'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}];
/* harmony default export */ var abi721 = (abi);
// CONCATENATED MODULE: ./ethereum/cryptoByte721.js


const instance = new web3["a" /* default */].eth.Contract(abi721, "0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5");
/* harmony default export */ var cryptoByte721 = __webpack_exports__["a"] = (instance);

/***/ }),

/***/ "oZBQ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("MDWq");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_0__);

let web3;

if (false) {} else {
  const provider = new web3__WEBPACK_IMPORTED_MODULE_0___default.a.providers.HttpProvider("https://mainnet.infura.io/v3/b459ad4f809e4892968c27f7b909cb2b");
  web3 = new web3__WEBPACK_IMPORTED_MODULE_0___default.a(provider);
}

/* harmony default export */ __webpack_exports__["a"] = (web3);

/***/ }),

/***/ "qcXG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jdenticon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("/arD");
/* harmony import */ var jdenticon__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jdenticon__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



class Jdenticon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  componentDidMount() {
    jdenticon__WEBPACK_IMPORTED_MODULE_1___default()();
  }

  render() {
    return __jsx("svg", {
      width: this.props.size,
      height: this.props.size,
      "data-jdenticon-value": this.props.value
    });
  }

}

/* harmony default export */ __webpack_exports__["a"] = (Jdenticon);

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "yo71":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("FfxO");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("8cHP");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("oZBQ");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





let isMetaMask;

class MMPrompt extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      modalOpen: true,
      visibility: 'hidden'
    });

    _defineProperty(this, "handleClose", () => {
      this.setState({
        modalOpen: false
      });
    });

    _defineProperty(this, "handleOpen", () => {
      this.setState({
        modalOpen: true
      });
    });
  }

  async componentDidMount() {
    isMetaMask = await _ethereum_web3__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"].currentProvider.isMetaMask;

    if (isMetaMask || this.props.visible === false) {
      this.handleClose();
    }
  }

  render() {
    return __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"], {
      size: "small",
      open: this.state.modalOpen,
      trigger: this.props.trigger,
      onClose: this.handleClose,
      onOpen: this.handleOpen
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Header"], {
      as: "h3"
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
      src: "/static/images/download-metamask-dark.png",
      as: "a",
      href: "https://metamask.io/",
      target: "_blank"
    }), "Use MetaMask to interact with the smart contract"), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"].Content, {
      image: true,
      scrolling: true
    }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
      size: "medium",
      src: "/static/images/metamask-network.png"
    }), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"].Description, null, __jsx("p", null, "To interact with the Crypto Byte Collectible smart contract, you'll need to have the", ' ', __jsx(_routes__WEBPACK_IMPORTED_MODULE_2__["Link"], {
      route: "https://metamask.io/"
    }, __jsx("a", {
      target: "_blank"
    }, "MetaMask")), ' ', "browser extension.", __jsx("br", null), "Make sure you're connected to the Main Ethereum Network."))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Modal"].Actions, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      color: "green",
      inverted: true,
      onClick: this.handleClose
    }, "Close")));
  }

}

/* harmony default export */ __webpack_exports__["a"] = (MMPrompt);

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });