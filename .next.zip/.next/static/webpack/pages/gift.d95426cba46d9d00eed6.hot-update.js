webpackHotUpdate_N_E("pages/gift",{

/***/ "./pages/gift/index.js":
/*!*****************************!*\
  !*** ./pages/gift/index.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/Layout */ "./components/Layout.js");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../ethereum/cryptoByte721 */ "./ethereum/cryptoByte721.js");
/* harmony import */ var _components_MMPrompt__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../components/MMPrompt */ "./components/MMPrompt.js");
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../ethereum/web3 */ "./ethereum/web3.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! next/head */ "./node_modules/next/dist/next-server/lib/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_15__);










var __jsx = react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }








var currentAccount, headerEl;

var GiftToken = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(GiftToken, _Component);

  var _super = _createSuper(GiftToken);

  function GiftToken() {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, GiftToken);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "state", {
      mounted: false,
      headerHeight: 0,
      recAddr: '',
      recAddrErr: false,
      msgErr: false,
      loading: false,
      success: false
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "onSubmit", /*#__PURE__*/function () {
      var _ref = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(event) {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                event.preventDefault();

                _this.setState({
                  loading: true,
                  msgErr: ''
                });

                _context.prev = 2;

                if (!(_this.state.recAddrErr || _this.state.recAddr === '')) {
                  _context.next = 5;
                  break;
                }

                throw {
                  message: 'Invalid receiver address.'
                };

              case 5:
                _context.next = 7;
                return _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__["default"].methods.safeTransferFrom(currentAccount, _this.state.recAddr, _this.props.id).send({
                  from: currentAccount
                });

              case 7:
                _this.setState({
                  loading: false,
                  success: true
                });

                _context.next = 13;
                break;

              case 10:
                _context.prev = 10;
                _context.t0 = _context["catch"](2);

                _this.setState({
                  loading: false,
                  msgErr: "You aren't logged in your MetaMask account."
                });

              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[2, 10]]);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());

    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(GiftToken, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        var _this2 = this;

        var headerVisible;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _ethereum_web3__WEBPACK_IMPORTED_MODULE_14__["default"].eth.getAccounts();

              case 2:
                currentAccount = _context2.sent[0];
                headerEl = document.getElementById('header');
                headerVisible = setInterval(function () {
                  if (headerEl.style.visibility === 'visible') {
                    _this2.setState({
                      headerHeight: headerEl.clientHeight
                    });

                    clearInterval(headerVisible);
                  }
                }, 100);
                this.setState({
                  mounted: true
                });

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_10__["default"], {
        mounted: this.state.mounted
      }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_15___default.a, null, __jsx("title", null, "Crypto Byte Collectible - Gift Tokens"), __jsx("meta", {
        name: "description",
        content: "Gift your Crypto Byte Collectible tokens for free."
      }), __jsx("meta", {
        name: "robots",
        content: "index, follow"
      })), __jsx(_components_MMPrompt__WEBPACK_IMPORTED_MODULE_13__["default"], null), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Container"], {
        style: {
          marginTop: this.state.headerHeight + 20
        }
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Header"], {
        as: "h3",
        inverted: true,
        dividing: true,
        textAlign: "center"
      }, "You can gift your ERC721 tokens with the form below."), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Form"], {
        inverted: true,
        onSubmit: this.onSubmit
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Form"].Group, {
        widths: "equal"
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Form"].Input, {
        error: this.state.recAddrErr,
        label: "Receiver address"
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Input"], {
        placeholder: "0x0000000000000000000000000000000000000000",
        value: this.state.recAddr,
        onChange: function onChange(event) {
          _this3.setState({
            recAddr: event.target.value
          });

          if (!event.target.value.match(/^(0x||0X)[a-fA-F0-9]{40}$/g) && !(event.target.value === '')) {
            _this3.setState({
              recAddrErr: {
                content: 'Please enter a valid address.'
              }
            });
          } else {
            _this3.setState({
              recAddrErr: false
            });
          }
        }
      }))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Message"], {
        info: true
      }, __jsx("p", null, "This is going to transact the ERC721 token with", ' ', __jsx("b", null, "ID ", this.props.id), " from your account.", __jsx("br", null), "Once the transaction is done, you can't get your token back. To avoid any inconveniences, please double check the receiver address (and you should also ", __jsx("b", null, "never"), " hand type addresses).")), this.state.msgErr && __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Message"], {
        negative: true,
        compact: true
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Message"].Header, null, "Something went wrong!"), this.state.msgErr), __jsx("br", null)), this.state.success && __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Message"], {
        positive: true,
        compact: true
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Message"].Header, null, "Transaction complete!"), "The transaction was completed successfully."), __jsx("br", null)), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Button"], {
        type: "submit",
        loading: this.state.loading,
        disabled: this.state.loading
      }, "Submit"))));
    }
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(_ref2) {
        var query;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                query = _ref2.query;
                return _context3.abrupt("return", {
                  id: query.id
                });

              case 2:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));

      function getInitialProps(_x2) {
        return _getInitialProps.apply(this, arguments);
      }

      return getInitialProps;
    }()
  }]);

  return GiftToken;
}(react__WEBPACK_IMPORTED_MODULE_9__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (GiftToken);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvZ2lmdC9pbmRleC5qcyJdLCJuYW1lcyI6WyJjdXJyZW50QWNjb3VudCIsImhlYWRlckVsIiwiR2lmdFRva2VuIiwibW91bnRlZCIsImhlYWRlckhlaWdodCIsInJlY0FkZHIiLCJyZWNBZGRyRXJyIiwibXNnRXJyIiwibG9hZGluZyIsInN1Y2Nlc3MiLCJldmVudCIsInByZXZlbnREZWZhdWx0Iiwic2V0U3RhdGUiLCJzdGF0ZSIsIm1lc3NhZ2UiLCJjcnlwdG9CeXRlNzIxIiwibWV0aG9kcyIsInNhZmVUcmFuc2ZlckZyb20iLCJwcm9wcyIsImlkIiwic2VuZCIsImZyb20iLCJ3ZWIzIiwiZXRoIiwiZ2V0QWNjb3VudHMiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiaGVhZGVyVmlzaWJsZSIsInNldEludGVydmFsIiwic3R5bGUiLCJ2aXNpYmlsaXR5IiwiY2xpZW50SGVpZ2h0IiwiY2xlYXJJbnRlcnZhbCIsIm1hcmdpblRvcCIsIm9uU3VibWl0IiwidGFyZ2V0IiwidmFsdWUiLCJtYXRjaCIsImNvbnRlbnQiLCJxdWVyeSIsIkNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsSUFBSUEsY0FBSixFQUFvQkMsUUFBcEI7O0lBRU1DLFM7Ozs7Ozs7Ozs7Ozs7Ozs7Z05BQ0k7QUFDTkMsYUFBTyxFQUFFLEtBREg7QUFFTkMsa0JBQVksRUFBRSxDQUZSO0FBR05DLGFBQU8sRUFBRSxFQUhIO0FBSU5DLGdCQUFVLEVBQUUsS0FKTjtBQUtOQyxZQUFNLEVBQUUsS0FMRjtBQU1OQyxhQUFPLEVBQUUsS0FOSDtBQU9OQyxhQUFPLEVBQUU7QUFQSCxLOzs7a01BK0JHLGlCQUFPQyxLQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDVEEscUJBQUssQ0FBQ0MsY0FBTjs7QUFDQSxzQkFBS0MsUUFBTCxDQUFjO0FBQUVKLHlCQUFPLEVBQUUsSUFBWDtBQUFpQkQsd0JBQU0sRUFBRTtBQUF6QixpQkFBZDs7QUFGUzs7QUFBQSxzQkFJSCxNQUFLTSxLQUFMLENBQVdQLFVBQVgsSUFBeUIsTUFBS08sS0FBTCxDQUFXUixPQUFYLEtBQXVCLEVBSjdDO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQUtDO0FBQUVTLHlCQUFPLEVBQUU7QUFBWCxpQkFMRDs7QUFBQTtBQUFBO0FBQUEsdUJBUURDLGdFQUFhLENBQUNDLE9BQWQsQ0FDSEMsZ0JBREcsQ0FDY2pCLGNBRGQsRUFDOEIsTUFBS2EsS0FBTCxDQUFXUixPQUR6QyxFQUNrRCxNQUFLYSxLQUFMLENBQVdDLEVBRDdELEVBRUhDLElBRkcsQ0FFRTtBQUNKQyxzQkFBSSxFQUFFckI7QUFERixpQkFGRixDQVJDOztBQUFBO0FBY1Asc0JBQUtZLFFBQUwsQ0FBYztBQUFFSix5QkFBTyxFQUFFLEtBQVg7QUFBa0JDLHlCQUFPLEVBQUU7QUFBM0IsaUJBQWQ7O0FBZE87QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBZ0JQLHNCQUFLRyxRQUFMLENBQWM7QUFDWkoseUJBQU8sRUFBRSxLQURHO0FBRVpELHdCQUFNLEVBQUU7QUFGSSxpQkFBZDs7QUFoQk87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFoQmVlLHVEQUFJLENBQUNDLEdBQUwsQ0FBU0MsV0FBVCxFOzs7QUFBeEJ4Qiw4QixrQkFBZ0QsQztBQUVoREMsd0JBQVEsR0FBR3dCLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixRQUF4QixDQUFYO0FBRU1DLDZCLEdBQWdCQyxXQUFXLENBQUMsWUFBTTtBQUN0QyxzQkFBSTNCLFFBQVEsQ0FBQzRCLEtBQVQsQ0FBZUMsVUFBZixLQUE4QixTQUFsQyxFQUE2QztBQUMzQywwQkFBSSxDQUFDbEIsUUFBTCxDQUFjO0FBQ1pSLGtDQUFZLEVBQUVILFFBQVEsQ0FBQzhCO0FBRFgscUJBQWQ7O0FBR0FDLGlDQUFhLENBQUNMLGFBQUQsQ0FBYjtBQUNEO0FBQ0YsaUJBUGdDLEVBTzlCLEdBUDhCLEM7QUFTakMscUJBQUtmLFFBQUwsQ0FBYztBQUFFVCx5QkFBTyxFQUFFO0FBQVgsaUJBQWQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkEwQk87QUFBQTs7QUFDUCxhQUNFLE1BQUMsMkRBQUQ7QUFBUSxlQUFPLEVBQUUsS0FBS1UsS0FBTCxDQUFXVjtBQUE1QixTQUNFLE1BQUMsaURBQUQsUUFDRSw2REFERixFQUVFO0FBQ0UsWUFBSSxFQUFDLGFBRFA7QUFFRSxlQUFPLEVBQUM7QUFGVixRQUZGLEVBTUU7QUFBTSxZQUFJLEVBQUMsUUFBWDtBQUFvQixlQUFPLEVBQUM7QUFBNUIsUUFORixDQURGLEVBU0UsTUFBQyw2REFBRCxPQVRGLEVBV0UsTUFBQyw0REFBRDtBQUNFLGFBQUssRUFBRTtBQUNMOEIsbUJBQVMsRUFBRSxLQUFLcEIsS0FBTCxDQUFXVCxZQUFYLEdBQTBCO0FBRGhDO0FBRFQsU0FLRSxNQUFDLHlEQUFEO0FBQVEsVUFBRSxFQUFDLElBQVg7QUFBZ0IsZ0JBQVEsTUFBeEI7QUFBeUIsZ0JBQVEsTUFBakM7QUFBa0MsaUJBQVMsRUFBQztBQUE1QyxnRUFMRixFQVNFLE1BQUMsdURBQUQ7QUFBTSxnQkFBUSxNQUFkO0FBQWUsZ0JBQVEsRUFBRSxLQUFLOEI7QUFBOUIsU0FDRSxNQUFDLHVEQUFELENBQU0sS0FBTjtBQUFZLGNBQU0sRUFBQztBQUFuQixTQUNFLE1BQUMsdURBQUQsQ0FBTSxLQUFOO0FBQ0UsYUFBSyxFQUFFLEtBQUtyQixLQUFMLENBQVdQLFVBRHBCO0FBRUUsYUFBSyxFQUFDO0FBRlIsU0FJRSxNQUFDLHdEQUFEO0FBQ0UsbUJBQVcsRUFBQyw0Q0FEZDtBQUVFLGFBQUssRUFBRSxLQUFLTyxLQUFMLENBQVdSLE9BRnBCO0FBR0UsZ0JBQVEsRUFBRSxrQkFBQ0ssS0FBRCxFQUFXO0FBQ25CLGdCQUFJLENBQUNFLFFBQUwsQ0FBYztBQUFFUCxtQkFBTyxFQUFFSyxLQUFLLENBQUN5QixNQUFOLENBQWFDO0FBQXhCLFdBQWQ7O0FBRUEsY0FDRSxDQUFDMUIsS0FBSyxDQUFDeUIsTUFBTixDQUFhQyxLQUFiLENBQW1CQyxLQUFuQixDQUF5Qiw0QkFBekIsQ0FBRCxJQUNBLEVBQUUzQixLQUFLLENBQUN5QixNQUFOLENBQWFDLEtBQWIsS0FBdUIsRUFBekIsQ0FGRixFQUdFO0FBQ0Esa0JBQUksQ0FBQ3hCLFFBQUwsQ0FBYztBQUNaTix3QkFBVSxFQUFFO0FBQ1ZnQyx1QkFBTyxFQUFFO0FBREM7QUFEQSxhQUFkO0FBS0QsV0FURCxNQVNPO0FBQ0wsa0JBQUksQ0FBQzFCLFFBQUwsQ0FBYztBQUFFTix3QkFBVSxFQUFFO0FBQWQsYUFBZDtBQUNEO0FBQ0Y7QUFsQkgsUUFKRixDQURGLENBREYsRUE2QkUsTUFBQywwREFBRDtBQUFTLFlBQUk7QUFBYixTQUNFLG9FQUNrRCxHQURsRCxFQUVFLHdCQUFPLEtBQUtZLEtBQUwsQ0FBV0MsRUFBbEIsQ0FGRix5QkFHRSxpQkFIRiw4SkFNK0IseUJBTi9CLDJCQURGLENBN0JGLEVBd0NHLEtBQUtOLEtBQUwsQ0FBV04sTUFBWCxJQUNDLG1CQUNFLE1BQUMsMERBQUQ7QUFBUyxnQkFBUSxNQUFqQjtBQUFrQixlQUFPO0FBQXpCLFNBQ0UsTUFBQywwREFBRCxDQUFTLE1BQVQsZ0NBREYsRUFFRyxLQUFLTSxLQUFMLENBQVdOLE1BRmQsQ0FERixFQUtFLGlCQUxGLENBekNKLEVBa0RHLEtBQUtNLEtBQUwsQ0FBV0osT0FBWCxJQUNDLG1CQUNFLE1BQUMsMERBQUQ7QUFBUyxnQkFBUSxNQUFqQjtBQUFrQixlQUFPO0FBQXpCLFNBQ0UsTUFBQywwREFBRCxDQUFTLE1BQVQsZ0NBREYsZ0RBREYsRUFLRSxpQkFMRixDQW5ESixFQTJERSxNQUFDLHlEQUFEO0FBQ0UsWUFBSSxFQUFDLFFBRFA7QUFFRSxlQUFPLEVBQUUsS0FBS0ksS0FBTCxDQUFXTCxPQUZ0QjtBQUdFLGdCQUFRLEVBQUUsS0FBS0ssS0FBTCxDQUFXTDtBQUh2QixrQkEzREYsQ0FURixDQVhGLENBREY7QUEyRkQ7Ozs7Ozs7Ozs7QUF4SThCK0IscUIsU0FBQUEsSztrREFDdEI7QUFBRXBCLG9CQUFFLEVBQUVvQixLQUFLLENBQUNwQjtBQUFaLGlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBWmFxQiwrQzs7QUFzSlR0Qyx3RUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9naWZ0LmQ5NTQyNmNiYTQ2ZDlkMDBlZWQ2LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9MYXlvdXQnO1xyXG5pbXBvcnQge1xyXG4gIENvbnRhaW5lcixcclxuICBIZWFkZXIsXHJcbiAgRm9ybSxcclxuICBCdXR0b24sXHJcbiAgSW5wdXQsXHJcbiAgTWVzc2FnZSxcclxufSBmcm9tICdzZW1hbnRpYy11aS1yZWFjdCc7XHJcbmltcG9ydCBjcnlwdG9CeXRlNzIxIGZyb20gJy4uLy4uL2V0aGVyZXVtL2NyeXB0b0J5dGU3MjEnO1xyXG5pbXBvcnQgTU1Qcm9tcHQgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9NTVByb21wdCc7XHJcbmltcG9ydCB3ZWIzIGZyb20gJy4uLy4uL2V0aGVyZXVtL3dlYjMnO1xyXG5pbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnO1xyXG5cclxubGV0IGN1cnJlbnRBY2NvdW50LCBoZWFkZXJFbDtcclxuXHJcbmNsYXNzIEdpZnRUb2tlbiBleHRlbmRzIENvbXBvbmVudCB7XHJcbiAgc3RhdGUgPSB7XHJcbiAgICBtb3VudGVkOiBmYWxzZSxcclxuICAgIGhlYWRlckhlaWdodDogMCxcclxuICAgIHJlY0FkZHI6ICcnLFxyXG4gICAgcmVjQWRkckVycjogZmFsc2UsXHJcbiAgICBtc2dFcnI6IGZhbHNlLFxyXG4gICAgbG9hZGluZzogZmFsc2UsXHJcbiAgICBzdWNjZXNzOiBmYWxzZSxcclxuICB9O1xyXG5cclxuICBzdGF0aWMgYXN5bmMgZ2V0SW5pdGlhbFByb3BzKHsgcXVlcnkgfSkge1xyXG4gICAgcmV0dXJuIHsgaWQ6IHF1ZXJ5LmlkIH07XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb21wb25lbnREaWRNb3VudCgpIHtcclxuICAgIGN1cnJlbnRBY2NvdW50ID0gKGF3YWl0IHdlYjMuZXRoLmdldEFjY291bnRzKCkpWzBdO1xyXG5cclxuICAgIGhlYWRlckVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2hlYWRlcicpO1xyXG5cclxuICAgIGNvbnN0IGhlYWRlclZpc2libGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGlmIChoZWFkZXJFbC5zdHlsZS52aXNpYmlsaXR5ID09PSAndmlzaWJsZScpIHtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgIGhlYWRlckhlaWdodDogaGVhZGVyRWwuY2xpZW50SGVpZ2h0LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNsZWFySW50ZXJ2YWwoaGVhZGVyVmlzaWJsZSk7XHJcbiAgICAgIH1cclxuICAgIH0sIDEwMCk7XHJcblxyXG4gICAgdGhpcy5zZXRTdGF0ZSh7IG1vdW50ZWQ6IHRydWUgfSk7XHJcbiAgfVxyXG5cclxuICBvblN1Ym1pdCA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRoaXMuc2V0U3RhdGUoeyBsb2FkaW5nOiB0cnVlLCBtc2dFcnI6ICcnIH0pO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKHRoaXMuc3RhdGUucmVjQWRkckVyciB8fCB0aGlzLnN0YXRlLnJlY0FkZHIgPT09ICcnKSB7XHJcbiAgICAgICAgdGhyb3cgeyBtZXNzYWdlOiAnSW52YWxpZCByZWNlaXZlciBhZGRyZXNzLicgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgYXdhaXQgY3J5cHRvQnl0ZTcyMS5tZXRob2RzXHJcbiAgICAgICAgLnNhZmVUcmFuc2ZlckZyb20oY3VycmVudEFjY291bnQsIHRoaXMuc3RhdGUucmVjQWRkciwgdGhpcy5wcm9wcy5pZClcclxuICAgICAgICAuc2VuZCh7XHJcbiAgICAgICAgICBmcm9tOiBjdXJyZW50QWNjb3VudCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBsb2FkaW5nOiBmYWxzZSwgc3VjY2VzczogdHJ1ZSB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICBsb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBtc2dFcnI6IFwiWW91IGFyZW4ndCBsb2dnZWQgaW4geW91ciBNZXRhTWFzayBhY2NvdW50LlwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8TGF5b3V0IG1vdW50ZWQ9e3RoaXMuc3RhdGUubW91bnRlZH0+XHJcbiAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICA8dGl0bGU+Q3J5cHRvIEJ5dGUgQ29sbGVjdGlibGUgLSBHaWZ0IFRva2VuczwvdGl0bGU+XHJcbiAgICAgICAgICA8bWV0YVxyXG4gICAgICAgICAgICBuYW1lPVwiZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICBjb250ZW50PVwiR2lmdCB5b3VyIENyeXB0byBCeXRlIENvbGxlY3RpYmxlIHRva2VucyBmb3IgZnJlZS5cIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxtZXRhIG5hbWU9XCJyb2JvdHNcIiBjb250ZW50PVwiaW5kZXgsIGZvbGxvd1wiIC8+XHJcbiAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgIDxNTVByb21wdCAvPlxyXG5cclxuICAgICAgICA8Q29udGFpbmVyXHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IHRoaXMuc3RhdGUuaGVhZGVySGVpZ2h0ICsgMjAsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxIZWFkZXIgYXM9XCJoM1wiIGludmVydGVkIGRpdmlkaW5nIHRleHRBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICBZb3UgY2FuIGdpZnQgeW91ciBFUkM3MjEgdG9rZW5zIHdpdGggdGhlIGZvcm0gYmVsb3cuXHJcbiAgICAgICAgICA8L0hlYWRlcj5cclxuXHJcbiAgICAgICAgICA8Rm9ybSBpbnZlcnRlZCBvblN1Ym1pdD17dGhpcy5vblN1Ym1pdH0+XHJcbiAgICAgICAgICAgIDxGb3JtLkdyb3VwIHdpZHRocz1cImVxdWFsXCI+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSW5wdXRcclxuICAgICAgICAgICAgICAgIGVycm9yPXt0aGlzLnN0YXRlLnJlY0FkZHJFcnJ9XHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIlJlY2VpdmVyIGFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjB4MDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLnJlY0FkZHJ9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgcmVjQWRkcjogZXZlbnQudGFyZ2V0LnZhbHVlIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAhZXZlbnQudGFyZ2V0LnZhbHVlLm1hdGNoKC9eKDB4fHwwWClbYS1mQS1GMC05XXs0MH0kL2cpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAhKGV2ZW50LnRhcmdldC52YWx1ZSA9PT0gJycpXHJcbiAgICAgICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVjQWRkckVycjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICdQbGVhc2UgZW50ZXIgYSB2YWxpZCBhZGRyZXNzLicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IHJlY0FkZHJFcnI6IGZhbHNlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLklucHV0PlxyXG4gICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XHJcblxyXG4gICAgICAgICAgICA8TWVzc2FnZSBpbmZvPlxyXG4gICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgVGhpcyBpcyBnb2luZyB0byB0cmFuc2FjdCB0aGUgRVJDNzIxIHRva2VuIHdpdGh7JyAnfVxyXG4gICAgICAgICAgICAgICAgPGI+SUQge3RoaXMucHJvcHMuaWR9PC9iPiBmcm9tIHlvdXIgYWNjb3VudC5cclxuICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgT25jZSB0aGUgdHJhbnNhY3Rpb24gaXMgZG9uZSwgeW91IGNhbid0IGdldCB5b3VyIHRva2VuIGJhY2suIFRvXHJcbiAgICAgICAgICAgICAgICBhdm9pZCBhbnkgaW5jb252ZW5pZW5jZXMsIHBsZWFzZSBkb3VibGUgY2hlY2sgdGhlIHJlY2VpdmVyXHJcbiAgICAgICAgICAgICAgICBhZGRyZXNzIChhbmQgeW91IHNob3VsZCBhbHNvIDxiPm5ldmVyPC9iPiBoYW5kIHR5cGUgYWRkcmVzc2VzKS5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvTWVzc2FnZT5cclxuXHJcbiAgICAgICAgICAgIHt0aGlzLnN0YXRlLm1zZ0VyciAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxNZXNzYWdlIG5lZ2F0aXZlIGNvbXBhY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDxNZXNzYWdlLkhlYWRlcj5Tb21ldGhpbmcgd2VudCB3cm9uZyE8L01lc3NhZ2UuSGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgICB7dGhpcy5zdGF0ZS5tc2dFcnJ9XHJcbiAgICAgICAgICAgICAgICA8L01lc3NhZ2U+XHJcbiAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHt0aGlzLnN0YXRlLnN1Y2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8TWVzc2FnZSBwb3NpdGl2ZSBjb21wYWN0PlxyXG4gICAgICAgICAgICAgICAgICA8TWVzc2FnZS5IZWFkZXI+VHJhbnNhY3Rpb24gY29tcGxldGUhPC9NZXNzYWdlLkhlYWRlcj5cclxuICAgICAgICAgICAgICAgICAgVGhlIHRyYW5zYWN0aW9uIHdhcyBjb21wbGV0ZWQgc3VjY2Vzc2Z1bGx5LlxyXG4gICAgICAgICAgICAgICAgPC9NZXNzYWdlPlxyXG4gICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXt0aGlzLnN0YXRlLmxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RoaXMuc3RhdGUubG9hZGluZ31cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFN1Ym1pdFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgPC9MYXlvdXQ+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgR2lmdFRva2VuO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9