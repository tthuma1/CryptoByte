webpackHotUpdate_N_E("pages/media",{

/***/ "./pages/media.js":
/*!************************!*\
  !*** ./pages/media.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! next/head */ "./node_modules/next/dist/next-server/lib/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_12__);









var __jsx = react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }





var headerEl;

var Media = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(Media, _Component);

  var _super = _createSuper(Media);

  function Media() {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Media);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "state", {
      mounted: false,
      headerHeight: 0
    });

    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(Media, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var _this2 = this;

        var headerVisible;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                headerEl = document.getElementById('header');
                headerVisible = setInterval(function () {
                  if (headerEl.style.visibility === 'visible') {
                    _this2.setState({
                      headerHeight: headerEl.clientHeight
                    });

                    clearInterval(headerVisible);
                  }
                }, 100);
                this.setState({
                  mounted: true
                });

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_10__["default"], {
        mounted: this.state.mounted
      }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_12___default.a, null, __jsx("title", null, "Crypto Byte Collectible - Sell Tokens"), __jsx("meta", {
        name: "description",
        content: "Media related to Crypto Byte Collectible tokens."
      }), __jsx("meta", {
        name: "robots",
        content: "index, follow"
      })), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Container"], {
        textAlign: "center",
        style: {
          marginTop: this.state.headerHeight + 20,
          color: 'rgba(255,255,255,.9)'
        }
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Grid"], {
        columns: 2
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Grid"].Row, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Grid"].Column, null, __jsx("img", {
        src: "/static/images/comic.jpg",
        height: "700"
      })), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Grid"].Column, null, __jsx("video", {
        height: "425",
        autoPlay: true,
        muted: true
      }, __jsx("source", {
        src: "/static/videos/final.mp4",
        type: "video/mp4"
      })), ' ')))));
    }
  }]);

  return Media;
}(react__WEBPACK_IMPORTED_MODULE_9__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Media);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvbWVkaWEuanMiXSwibmFtZXMiOlsiaGVhZGVyRWwiLCJNZWRpYSIsIm1vdW50ZWQiLCJoZWFkZXJIZWlnaHQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiaGVhZGVyVmlzaWJsZSIsInNldEludGVydmFsIiwic3R5bGUiLCJ2aXNpYmlsaXR5Iiwic2V0U3RhdGUiLCJjbGllbnRIZWlnaHQiLCJjbGVhckludGVydmFsIiwic3RhdGUiLCJtYXJnaW5Ub3AiLCJjb2xvciIsIkNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFJQSxRQUFKOztJQUVNQyxLOzs7Ozs7Ozs7Ozs7Ozs7O2dOQUNJO0FBQ05DLGFBQU8sRUFBRSxLQURIO0FBRU5DLGtCQUFZLEVBQUU7QUFGUixLOzs7Ozs7Ozs7Ozs7Ozs7O0FBTU5ILHdCQUFRLEdBQUdJLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixRQUF4QixDQUFYO0FBRU1DLDZCLEdBQWdCQyxXQUFXLENBQUMsWUFBTTtBQUN0QyxzQkFBSVAsUUFBUSxDQUFDUSxLQUFULENBQWVDLFVBQWYsS0FBOEIsU0FBbEMsRUFBNkM7QUFDM0MsMEJBQUksQ0FBQ0MsUUFBTCxDQUFjO0FBQ1pQLGtDQUFZLEVBQUVILFFBQVEsQ0FBQ1c7QUFEWCxxQkFBZDs7QUFHQUMsaUNBQWEsQ0FBQ04sYUFBRCxDQUFiO0FBQ0Q7QUFDRixpQkFQZ0MsRUFPOUIsR0FQOEIsQztBQVNqQyxxQkFBS0ksUUFBTCxDQUFjO0FBQUVSLHlCQUFPLEVBQUU7QUFBWCxpQkFBZDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzZCQUdPO0FBQ1AsYUFDRSxNQUFDLDJEQUFEO0FBQVEsZUFBTyxFQUFFLEtBQUtXLEtBQUwsQ0FBV1g7QUFBNUIsU0FDRSxNQUFDLGlEQUFELFFBQ0UsNkRBREYsRUFFRTtBQUNFLFlBQUksRUFBQyxhQURQO0FBRUUsZUFBTyxFQUFDO0FBRlYsUUFGRixFQU1FO0FBQU0sWUFBSSxFQUFDLFFBQVg7QUFBb0IsZUFBTyxFQUFDO0FBQTVCLFFBTkYsQ0FERixFQVNFLE1BQUMsNERBQUQ7QUFDRSxpQkFBUyxFQUFDLFFBRFo7QUFFRSxhQUFLLEVBQUU7QUFDTFksbUJBQVMsRUFBRSxLQUFLRCxLQUFMLENBQVdWLFlBQVgsR0FBMEIsRUFEaEM7QUFFTFksZUFBSyxFQUFFO0FBRkY7QUFGVCxTQU9FLE1BQUMsdURBQUQ7QUFBTSxlQUFPLEVBQUU7QUFBZixTQUNFLE1BQUMsdURBQUQsQ0FBTSxHQUFOLFFBQ0UsTUFBQyx1REFBRCxDQUFNLE1BQU4sUUFDRTtBQUFLLFdBQUcsRUFBQywwQkFBVDtBQUFvQyxjQUFNLEVBQUM7QUFBM0MsUUFERixDQURGLEVBSUUsTUFBQyx1REFBRCxDQUFNLE1BQU4sUUFDRTtBQUFPLGNBQU0sRUFBQyxLQUFkO0FBQW9CLGdCQUFRLE1BQTVCO0FBQTZCLGFBQUs7QUFBbEMsU0FDRTtBQUFRLFdBQUcsRUFBQywwQkFBWjtBQUF1QyxZQUFJLEVBQUM7QUFBNUMsUUFERixDQURGLEVBR1csR0FIWCxDQUpGLENBREYsQ0FQRixDQVRGLENBREY7QUFnQ0Q7Ozs7RUF0RGlCQywrQzs7QUF5RExmLG9FQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL21lZGlhLjEzNGE4M2ZjYzdkZDk3ZDViNDg3LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvTGF5b3V0JztcclxuaW1wb3J0IHsgQ29udGFpbmVyLCBHcmlkIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnO1xyXG5pbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnO1xyXG5cclxubGV0IGhlYWRlckVsO1xyXG5cclxuY2xhc3MgTWVkaWEgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gIHN0YXRlID0ge1xyXG4gICAgbW91bnRlZDogZmFsc2UsXHJcbiAgICBoZWFkZXJIZWlnaHQ6IDAsXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgY29tcG9uZW50RGlkTW91bnQoKSB7XHJcbiAgICBoZWFkZXJFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdoZWFkZXInKTtcclxuXHJcbiAgICBjb25zdCBoZWFkZXJWaXNpYmxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICBpZiAoaGVhZGVyRWwuc3R5bGUudmlzaWJpbGl0eSA9PT0gJ3Zpc2libGUnKSB7XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgICAgICBoZWFkZXJIZWlnaHQ6IGhlYWRlckVsLmNsaWVudEhlaWdodCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjbGVhckludGVydmFsKGhlYWRlclZpc2libGUpO1xyXG4gICAgICB9XHJcbiAgICB9LCAxMDApO1xyXG5cclxuICAgIHRoaXMuc2V0U3RhdGUoeyBtb3VudGVkOiB0cnVlIH0pO1xyXG4gIH1cclxuXHJcbiAgcmVuZGVyKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPExheW91dCBtb3VudGVkPXt0aGlzLnN0YXRlLm1vdW50ZWR9PlxyXG4gICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgPHRpdGxlPkNyeXB0byBCeXRlIENvbGxlY3RpYmxlIC0gU2VsbCBUb2tlbnM8L3RpdGxlPlxyXG4gICAgICAgICAgPG1ldGFcclxuICAgICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgY29udGVudD1cIk1lZGlhIHJlbGF0ZWQgdG8gQ3J5cHRvIEJ5dGUgQ29sbGVjdGlibGUgdG9rZW5zLlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPG1ldGEgbmFtZT1cInJvYm90c1wiIGNvbnRlbnQ9XCJpbmRleCwgZm9sbG93XCIgLz5cclxuICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgPENvbnRhaW5lclxyXG4gICAgICAgICAgdGV4dEFsaWduPVwiY2VudGVyXCJcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIG1hcmdpblRvcDogdGhpcy5zdGF0ZS5oZWFkZXJIZWlnaHQgKyAyMCxcclxuICAgICAgICAgICAgY29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LC45KScsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxHcmlkIGNvbHVtbnM9ezJ9PlxyXG4gICAgICAgICAgICA8R3JpZC5Sb3c+XHJcbiAgICAgICAgICAgICAgPEdyaWQuQ29sdW1uPlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvc3RhdGljL2ltYWdlcy9jb21pYy5qcGdcIiBoZWlnaHQ9XCI3MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvR3JpZC5Db2x1bW4+XHJcbiAgICAgICAgICAgICAgPEdyaWQuQ29sdW1uPlxyXG4gICAgICAgICAgICAgICAgPHZpZGVvIGhlaWdodD1cIjQyNVwiIGF1dG9QbGF5IG11dGVkPlxyXG4gICAgICAgICAgICAgICAgICA8c291cmNlIHNyYz1cIi9zdGF0aWMvdmlkZW9zL2ZpbmFsLm1wNFwiIHR5cGU9XCJ2aWRlby9tcDRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC92aWRlbz57JyAnfVxyXG4gICAgICAgICAgICAgIDwvR3JpZC5Db2x1bW4+XHJcbiAgICAgICAgICAgIDwvR3JpZC5Sb3c+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgIDwvTGF5b3V0PlxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1lZGlhO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9