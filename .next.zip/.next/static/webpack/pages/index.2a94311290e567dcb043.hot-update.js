webpackHotUpdate_N_E("pages/index",{

/***/ "./components/Footer.js":
/*!******************************!*\
  !*** ./components/Footer.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");






var __jsx = react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }




var Footer = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_2__["default"])(Footer, _Component);

  var _super = _createSuper(Footer);

  function Footer() {
    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Footer);

    return _super.apply(this, arguments);
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Footer, [{
    key: "render",
    value: function render() {
      return __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"], {
        style: {
          marginTop: '10vh',
          backgroundColor: 'rgba(255,255,255,.05)',
          color: 'white'
        }
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Row, {
        columns: 2
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Column, {
        textAlign: "right"
      }, __jsx("span", null, "Contract address:"), ' ', __jsx("a", {
        href: "https://etherscan.io/token/".concat("0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5"),
        target: "_blank"
      }, "0x0b722DC0F7A5611CE4bF3cFdEBA8D9ff3aBD39d5")), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Column, {
        textAlign: "left"
      }, "Contact us:", ' ', __jsx("a", {
        href: "mailto:info@crypto-byte.com"
      }, "info@crypto-byte.com"))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Row, {
        columns: 1,
        style: {
          fontSize: '23px'
        }
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Column, {
        textAlign: "center"
      }, __jsx("a", {
        href: "https://www.reddit.com/r/crypto_byte/",
        target: "_blank"
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
        name: "reddit",
        size: "big",
        style: {
          color: '#ccc',
          marginRight: '30px'
        }
      })), __jsx("a", {
        href: "https://twitter.com/crypto_byte721",
        target: "_blank"
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
        name: "twitter square",
        size: "big",
        style: {
          color: '#ccc',
          marginRight: '30px'
        }
      })), __jsx("a", {
        href: "https://t.me/Crypto_ByteERC721",
        target: "_blank"
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
        name: "telegram",
        size: "big",
        style: {
          color: '#ccc'
        }
      })))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Row, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_6__["Grid"].Column, {
        textAlign: "center"
      }, __jsx("p", {
        yle: {
          color: '#ccc'
        }
      }, "This website does not collect any cookies."))));
    }
  }]);

  return Footer;
}(react__WEBPACK_IMPORTED_MODULE_5__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Footer);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9Gb290ZXIuanMiXSwibmFtZXMiOlsiRm9vdGVyIiwibWFyZ2luVG9wIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJwcm9jZXNzIiwiZm9udFNpemUiLCJtYXJnaW5SaWdodCIsIkNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7O0lBRU1BLE07Ozs7Ozs7Ozs7Ozs7NkJBQ0s7QUFDUCxhQUNFLE1BQUMsc0RBQUQ7QUFDRSxhQUFLLEVBQUU7QUFDTEMsbUJBQVMsRUFBRSxNQUROO0FBRUxDLHlCQUFlLEVBQUUsdUJBRlo7QUFHTEMsZUFBSyxFQUFFO0FBSEY7QUFEVCxTQU9FLE1BQUMsc0RBQUQsQ0FBTSxHQUFOO0FBQVUsZUFBTyxFQUFFO0FBQW5CLFNBQ0UsTUFBQyxzREFBRCxDQUFNLE1BQU47QUFBYSxpQkFBUyxFQUFDO0FBQXZCLFNBQ0Usd0NBREYsRUFDaUMsR0FEakMsRUFFRTtBQUNFLFlBQUksdUNBQWdDQyw0Q0FBaEMsQ0FETjtBQUVFLGNBQU0sRUFBQztBQUZULFNBSUdBLDRDQUpILENBRkYsQ0FERixFQVdFLE1BQUMsc0RBQUQsQ0FBTSxNQUFOO0FBQWEsaUJBQVMsRUFBQztBQUF2Qix3QkFDYyxHQURkLEVBRUU7QUFBRyxZQUFJLEVBQUM7QUFBUixnQ0FGRixDQVhGLENBUEYsRUF3QkUsTUFBQyxzREFBRCxDQUFNLEdBQU47QUFBVSxlQUFPLEVBQUUsQ0FBbkI7QUFBc0IsYUFBSyxFQUFFO0FBQUVDLGtCQUFRLEVBQUU7QUFBWjtBQUE3QixTQUNFLE1BQUMsc0RBQUQsQ0FBTSxNQUFOO0FBQWEsaUJBQVMsRUFBQztBQUF2QixTQUNFO0FBQUcsWUFBSSxFQUFDLHVDQUFSO0FBQWdELGNBQU0sRUFBQztBQUF2RCxTQUNFLE1BQUMsc0RBQUQ7QUFDRSxZQUFJLEVBQUMsUUFEUDtBQUVFLFlBQUksRUFBQyxLQUZQO0FBR0UsYUFBSyxFQUFFO0FBQUVGLGVBQUssRUFBRSxNQUFUO0FBQWlCRyxxQkFBVyxFQUFFO0FBQTlCO0FBSFQsUUFERixDQURGLEVBU0U7QUFBRyxZQUFJLEVBQUMsb0NBQVI7QUFBNkMsY0FBTSxFQUFDO0FBQXBELFNBQ0UsTUFBQyxzREFBRDtBQUNFLFlBQUksRUFBQyxnQkFEUDtBQUVFLFlBQUksRUFBQyxLQUZQO0FBR0UsYUFBSyxFQUFFO0FBQUVILGVBQUssRUFBRSxNQUFUO0FBQWlCRyxxQkFBVyxFQUFFO0FBQTlCO0FBSFQsUUFERixDQVRGLEVBaUJFO0FBQUcsWUFBSSxFQUFDLGdDQUFSO0FBQXlDLGNBQU0sRUFBQztBQUFoRCxTQUNFLE1BQUMsc0RBQUQ7QUFBTSxZQUFJLEVBQUMsVUFBWDtBQUFzQixZQUFJLEVBQUMsS0FBM0I7QUFBaUMsYUFBSyxFQUFFO0FBQUVILGVBQUssRUFBRTtBQUFUO0FBQXhDLFFBREYsQ0FqQkYsQ0FERixDQXhCRixFQWdERSxNQUFDLHNEQUFELENBQU0sR0FBTixRQUNFLE1BQUMsc0RBQUQsQ0FBTSxNQUFOO0FBQWEsaUJBQVMsRUFBQztBQUF2QixTQUNFO0FBQUcsV0FBRyxFQUFFO0FBQUVBLGVBQUssRUFBRTtBQUFUO0FBQVIsc0RBREYsQ0FERixDQWhERixDQURGO0FBMEREOzs7O0VBNURrQkksK0M7O0FBK0ROUCxxRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4yYTk0MzExMjkwZTU2N2RjYjA0My5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBJY29uLCBHcmlkIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnO1xyXG5cclxuY2xhc3MgRm9vdGVyIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICByZW5kZXIoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8R3JpZFxyXG4gICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICBtYXJnaW5Ub3A6ICcxMHZoJyxcclxuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsLjA1KScsXHJcbiAgICAgICAgICBjb2xvcjogJ3doaXRlJyxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPEdyaWQuUm93IGNvbHVtbnM9ezJ9PlxyXG4gICAgICAgICAgPEdyaWQuQ29sdW1uIHRleHRBbGlnbj1cInJpZ2h0XCI+XHJcbiAgICAgICAgICAgIDxzcGFuPkNvbnRyYWN0IGFkZHJlc3M6PC9zcGFuPnsnICd9XHJcbiAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vZXRoZXJzY2FuLmlvL3Rva2VuLyR7cHJvY2Vzcy5lbnYuQUREUkVTU183MjF9YH1cclxuICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3Byb2Nlc3MuZW52LkFERFJFU1NfNzIxfVxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0dyaWQuQ29sdW1uPlxyXG5cclxuICAgICAgICAgIDxHcmlkLkNvbHVtbiB0ZXh0QWxpZ249XCJsZWZ0XCI+XHJcbiAgICAgICAgICAgIENvbnRhY3QgdXM6eycgJ31cclxuICAgICAgICAgICAgPGEgaHJlZj1cIm1haWx0bzppbmZvQGNyeXB0by1ieXRlLmNvbVwiPmluZm9AY3J5cHRvLWJ5dGUuY29tPC9hPlxyXG4gICAgICAgICAgPC9HcmlkLkNvbHVtbj5cclxuICAgICAgICA8L0dyaWQuUm93PlxyXG5cclxuICAgICAgICA8R3JpZC5Sb3cgY29sdW1ucz17MX0gc3R5bGU9e3sgZm9udFNpemU6ICcyM3B4JyB9fT5cclxuICAgICAgICAgIDxHcmlkLkNvbHVtbiB0ZXh0QWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vd3d3LnJlZGRpdC5jb20vci9jcnlwdG9fYnl0ZS9cIiB0YXJnZXQ9XCJfYmxhbmtcIj5cclxuICAgICAgICAgICAgICA8SWNvblxyXG4gICAgICAgICAgICAgICAgbmFtZT1cInJlZGRpdFwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwiYmlnXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiAnI2NjYycsIG1hcmdpblJpZ2h0OiAnMzBweCcgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2E+XHJcblxyXG4gICAgICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly90d2l0dGVyLmNvbS9jcnlwdG9fYnl0ZTcyMVwiIHRhcmdldD1cIl9ibGFua1wiPlxyXG4gICAgICAgICAgICAgIDxJY29uXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwidHdpdHRlciBzcXVhcmVcIlxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImJpZ1wiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogJyNjY2MnLCBtYXJnaW5SaWdodDogJzMwcHgnIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9hPlxyXG5cclxuICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vdC5tZS9DcnlwdG9fQnl0ZUVSQzcyMVwiIHRhcmdldD1cIl9ibGFua1wiPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJ0ZWxlZ3JhbVwiIHNpemU9XCJiaWdcIiBzdHlsZT17eyBjb2xvcjogJyNjY2MnIH19IC8+XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgIDwvR3JpZC5Db2x1bW4+XHJcbiAgICAgICAgPC9HcmlkLlJvdz5cclxuXHJcbiAgICAgICAgPEdyaWQuUm93PlxyXG4gICAgICAgICAgPEdyaWQuQ29sdW1uIHRleHRBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICA8cCB5bGU9e3sgY29sb3I6ICcjY2NjJyB9fT5cclxuICAgICAgICAgICAgICBUaGlzIHdlYnNpdGUgZG9lcyBub3QgY29sbGVjdCBhbnkgY29va2llcy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9HcmlkLkNvbHVtbj5cclxuICAgICAgICA8L0dyaWQuUm93PlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9