webpackHotUpdate_N_E("pages/tokens",{

/***/ "./pages/tokens/index.js":
/*!*******************************!*\
  !*** ./pages/tokens/index.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/Layout */ "./components/Layout.js");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../ethereum/cryptoByte721 */ "./ethereum/cryptoByte721.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../ethereum/web3 */ "./ethereum/web3.js");
/* harmony import */ var _components_Jdenticon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../components/Jdenticon */ "./components/Jdenticon.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_MMPrompt__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../components/MMPrompt */ "./components/MMPrompt.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! next/head */ "./node_modules/next/dist/next-server/lib/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_18__);










var __jsx = react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }











var headerEl;
var currentAccount;
var viking = "1,2,3,4,5,6".split(',');
var vikingAmount = viking.length;
var specialEdition = "7,8,9".split(',');
var specialEditionAmount = specialEdition.length;
var specialTokens = viking.concat(specialEdition);
var specialTokensAmount = vikingAmount + specialEditionAmount;

var AllTokens = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(AllTokens, _Component);

  var _super = _createSuper(AllTokens);

  function AllTokens() {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, AllTokens);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "state", {
      mounted: false,
      headerHeight: 0,
      images: {},
      buyLoading: {},
      jdentHeigth: 174,
      tokenInfo: {}
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "getTokenInfo", /*#__PURE__*/Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      var tokenInfo, images, id;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              tokenInfo = {};
              images = {};
              id = 1;

            case 3:
              if (!(id <= _this.props.supply)) {
                _context.next = 24;
                break;
              }

              tokenInfo[id] = {};
              _context.next = 7;
              return _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__["default"].methods.ownerOf(id).call();

            case 7:
              tokenInfo[id]['owner'] = _context.sent;
              _context.next = 10;
              return _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__["default"].methods.getTokenPrice(id).call();

            case 10:
              tokenInfo[id]['price'] = _context.sent;
              _context.prev = 11;
              _context.next = 14;
              return axios__WEBPACK_IMPORTED_MODULE_16___default.a.get("../static/images/ERC721/".concat(id, "_w.jpg"));

            case 14:
              images[id] = true;
              _context.next = 20;
              break;

            case 17:
              _context.prev = 17;
              _context.t0 = _context["catch"](11);
              images[id] = false;

            case 20:
              _this.setState({
                tokenInfo: tokenInfo,
                images: images
              });

            case 21:
              id++;
              _context.next = 3;
              break;

            case 24:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[11, 17]]);
    })));

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "buyToken", /*#__PURE__*/function () {
      var _ref2 = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(event) {
        var id;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                id = event.target.name;
                event.preventDefault();

                _this.setState(function (prevState) {
                  var buyLoading = Object.assign({}, prevState.buyLoading);
                  buyLoading[id] = true;
                  return {
                    buyLoading: buyLoading
                  };
                });

                _context2.prev = 3;
                _context2.next = 6;
                return _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__["default"].methods.buyToken(id).send({
                  from: currentAccount,
                  value: _this.state.tokenInfo[id]['price']
                });

              case 6:
                _routes__WEBPACK_IMPORTED_MODULE_13__["Router"].replaceRoute('/tokens');
                _context2.next = 11;
                break;

              case 9:
                _context2.prev = 9;
                _context2.t0 = _context2["catch"](3);

              case 11:
                _this.setState(function (prevState) {
                  var buyLoading = Object.assign({}, prevState.buyLoading);
                  buyLoading[id] = false;
                  return {
                    buyLoading: buyLoading
                  };
                });

              case 12:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[3, 9]]);
      }));

      return function (_x) {
        return _ref2.apply(this, arguments);
      };
    }());

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "updateImage", /*#__PURE__*/function () {
      var _ref4 = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(e, _ref3) {
        var calculations;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                calculations = _ref3.calculations;

                _this.setState({
                  jdentHeigth: calculations.height - 40
                });

              case 2:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));

      return function (_x2, _x3) {
        return _ref4.apply(this, arguments);
      };
    }());

    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(AllTokens, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4() {
        var _this2 = this;

        var headerVisible;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return _ethereum_web3__WEBPACK_IMPORTED_MODULE_14__["default"].eth.getAccounts();

              case 2:
                currentAccount = _context4.sent[0];
                headerEl = document.getElementById('header');
                headerVisible = setInterval(function () {
                  if (headerEl.style.visibility === 'visible') {
                    _this2.setState({
                      transVisible: true,
                      headerHeight: headerEl.clientHeight
                    });

                    clearInterval(headerVisible);
                  }
                }, 100);
                this.setState({
                  mounted: true
                });
                this.getTokenInfo();

              case 7:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "renderTokens",
    value: function renderTokens() {
      var items = [];
      var classic = [];

      for (var id = 1; id <= this.props.supply; id++) {
        if (specialTokens.indexOf(String(id)) < 0) {
          classic.push(id);
        }
      }

      items.push(this.makeCards(viking), this.makeCards(specialEdition), this.makeCards(classic));
      return __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"].Group, {
        itemsPerRow: 3
      }, items);
    }
  }, {
    key: "makeCards",
    value: function makeCards(ids) {
      var _this3 = this;

      var items = [];

      for (var i = 0; i < ids.length; i++) {
        var id = ids[i];
        items.push(__jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"], {
          key: id
        }, this.state.tokenInfo[id] ? this.state.images[id] ? id == 1 ? __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Visibility"], {
          onUpdate: this.updateImage
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Image"], {
          src: "/static/images/ERC721/".concat(id, "_w.jpg")
        })) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Image"], {
          src: "/static/images/ERC721/".concat(id, "_w.jpg")
        }) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Container"], {
          textAlign: "center",
          style: {
            background: 'rgba(0,0,0,.05)',
            overflow: 'auto',
            paddingTop: '20px',
            paddingBottom: '20px'
          }
        }, __jsx(_components_Jdenticon__WEBPACK_IMPORTED_MODULE_15__["default"], {
          value: id,
          size: this.state.jdentHeigth
        })) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"], {
          fluid: true
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"].Image, {
          style: {
            height: this.state.jdentHeigth + 40
          }
        })), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"].Content, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"].Header, null, viking.indexOf(String(id)) >= 0 ? 'Viking Collection #' + id : specialEdition.indexOf(String(id)) >= 0 ? 'Special Edition #' + (id - vikingAmount) : 'CRBC Token #' + (id - specialTokensAmount)), this.state.tokenInfo[id] ? __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"].Description, null, __jsx("b", null, Number(this.state.tokenInfo[id]['price']) ? 'Token price: ' + _ethereum_web3__WEBPACK_IMPORTED_MODULE_14__["default"].utils.fromWei(this.state.tokenInfo[id]['price'], 'ether') + ' ETH' : 'Token not for sale')), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"].Meta, {
          style: {
            overflow: 'auto',
            fontSize: '0.9em'
          }
        }, "Owner", currentAccount == this.state.tokenInfo[id]['owner'] ? __jsx("b", {
          style: {
            color: 'rgba(0,0,0,.68)'
          }
        }, " (You)") : '', ": ", this.state.tokenInfo[id]['owner'])) : __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"], {
          style: {
            marginTop: '10px'
          }
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"].Header, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"].Line, {
          length: "very short"
        }), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"].Line, {
          length: "medium"
        })), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"].Paragraph, null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Placeholder"].Line, {
          length: "short"
        })))), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Card"].Content, {
          extra: true
        }, __jsx(_routes__WEBPACK_IMPORTED_MODULE_13__["Link"], {
          route: "/token/".concat(id)
        }, __jsx("a", {
          onClick: function onClick() {
            _this3.setState({
              mounted: false
            });
          }
        }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Button"], null, "View Details", __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Icon"], {
          name: "chevron circle right"
        })))), this.state.tokenInfo[id] ? Number(this.state.tokenInfo[id]['price']) && this.state.tokenInfo[id]['owner'] != currentAccount ? __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Button"], {
          name: id,
          primary: true,
          onClick: this.buyToken,
          loading: this.state.buyLoading[id],
          disabled: this.state.buyLoading[id],
          style: {
            marginTop: '5px'
          }
        }, "Buy token", __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Icon"], {
          name: "shopping cart right"
        })) : '' : '')));
      }

      return items;
    }
  }, {
    key: "render",
    value: function render() {
      return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_10__["default"], {
        mounted: this.state.mounted
      }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_18___default.a, null, __jsx("title", null, "Crypto Byte Collectible - All Tokens"), __jsx("meta", {
        name: "description",
        content: "View all existing Crypto Byte Collectible tokens and buy the ones that are up for sale."
      }), __jsx("meta", {
        name: "robots",
        content: "index, follow"
      })), __jsx(_components_MMPrompt__WEBPACK_IMPORTED_MODULE_17__["default"], null), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Container"], {
        textAlign: "center",
        style: {
          marginTop: this.state.headerHeight + 20
        }
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Header"], {
        as: "h2",
        dividing: true,
        inverted: true
      }, "There are currently ", this.props.supply, " existing tokens."), this.renderTokens()));
    }
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee5() {
        var supply;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_12__["default"].methods.totalSupply().call();

              case 2:
                supply = _context5.sent;
                return _context5.abrupt("return", {
                  supply: supply
                });

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }));

      function getInitialProps() {
        return _getInitialProps.apply(this, arguments);
      }

      return getInitialProps;
    }()
  }]);

  return AllTokens;
}(react__WEBPACK_IMPORTED_MODULE_9__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (AllTokens);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvdG9rZW5zL2luZGV4LmpzIl0sIm5hbWVzIjpbImhlYWRlckVsIiwiY3VycmVudEFjY291bnQiLCJ2aWtpbmciLCJwcm9jZXNzIiwic3BsaXQiLCJ2aWtpbmdBbW91bnQiLCJsZW5ndGgiLCJzcGVjaWFsRWRpdGlvbiIsInNwZWNpYWxFZGl0aW9uQW1vdW50Iiwic3BlY2lhbFRva2VucyIsImNvbmNhdCIsInNwZWNpYWxUb2tlbnNBbW91bnQiLCJBbGxUb2tlbnMiLCJtb3VudGVkIiwiaGVhZGVySGVpZ2h0IiwiaW1hZ2VzIiwiYnV5TG9hZGluZyIsImpkZW50SGVpZ3RoIiwidG9rZW5JbmZvIiwiaWQiLCJwcm9wcyIsInN1cHBseSIsImNyeXB0b0J5dGU3MjEiLCJtZXRob2RzIiwib3duZXJPZiIsImNhbGwiLCJnZXRUb2tlblByaWNlIiwiYXhpb3MiLCJnZXQiLCJzZXRTdGF0ZSIsImV2ZW50IiwidGFyZ2V0IiwibmFtZSIsInByZXZlbnREZWZhdWx0IiwicHJldlN0YXRlIiwiT2JqZWN0IiwiYXNzaWduIiwiYnV5VG9rZW4iLCJzZW5kIiwiZnJvbSIsInZhbHVlIiwic3RhdGUiLCJSb3V0ZXIiLCJyZXBsYWNlUm91dGUiLCJlIiwiY2FsY3VsYXRpb25zIiwiaGVpZ2h0Iiwid2ViMyIsImV0aCIsImdldEFjY291bnRzIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsImhlYWRlclZpc2libGUiLCJzZXRJbnRlcnZhbCIsInN0eWxlIiwidmlzaWJpbGl0eSIsInRyYW5zVmlzaWJsZSIsImNsaWVudEhlaWdodCIsImNsZWFySW50ZXJ2YWwiLCJnZXRUb2tlbkluZm8iLCJpdGVtcyIsImNsYXNzaWMiLCJpbmRleE9mIiwiU3RyaW5nIiwicHVzaCIsIm1ha2VDYXJkcyIsImlkcyIsImkiLCJ1cGRhdGVJbWFnZSIsImJhY2tncm91bmQiLCJvdmVyZmxvdyIsInBhZGRpbmdUb3AiLCJwYWRkaW5nQm90dG9tIiwiTnVtYmVyIiwidXRpbHMiLCJmcm9tV2VpIiwiZm9udFNpemUiLCJjb2xvciIsIm1hcmdpblRvcCIsInJlbmRlclRva2VucyIsInRvdGFsU3VwcGx5IiwiQ29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFVQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLElBQUlBLFFBQUo7QUFDQSxJQUFJQyxjQUFKO0FBQ0EsSUFBSUMsTUFBTSxHQUFHQyxhQUFBLENBQTBCQyxLQUExQixDQUFnQyxHQUFoQyxDQUFiO0FBQ0EsSUFBSUMsWUFBWSxHQUFHSCxNQUFNLENBQUNJLE1BQTFCO0FBQ0EsSUFBSUMsY0FBYyxHQUFHSixPQUFBLENBQTRCQyxLQUE1QixDQUFrQyxHQUFsQyxDQUFyQjtBQUNBLElBQUlJLG9CQUFvQixHQUFHRCxjQUFjLENBQUNELE1BQTFDO0FBQ0EsSUFBSUcsYUFBYSxHQUFHUCxNQUFNLENBQUNRLE1BQVAsQ0FBY0gsY0FBZCxDQUFwQjtBQUNBLElBQUlJLG1CQUFtQixHQUFHTixZQUFZLEdBQUdHLG9CQUF6Qzs7SUFFTUksUzs7Ozs7Ozs7Ozs7Ozs7OztnTkFDSTtBQUNOQyxhQUFPLEVBQUUsS0FESDtBQUVOQyxrQkFBWSxFQUFFLENBRlI7QUFHTkMsWUFBTSxFQUFFLEVBSEY7QUFJTkMsZ0JBQVUsRUFBRSxFQUpOO0FBS05DLGlCQUFXLEVBQUUsR0FMUDtBQU1OQyxlQUFTLEVBQUU7QUFOTCxLOztxWkFrQ087QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1RBLHVCQURTLEdBQ0csRUFESDtBQUVUSCxvQkFGUyxHQUVBLEVBRkE7QUFHSkksZ0JBSEksR0FHQyxDQUhEOztBQUFBO0FBQUEsb0JBR0lBLEVBQUUsSUFBSSxNQUFLQyxLQUFMLENBQVdDLE1BSHJCO0FBQUE7QUFBQTtBQUFBOztBQUlYSCx1QkFBUyxDQUFDQyxFQUFELENBQVQsR0FBZ0IsRUFBaEI7QUFKVztBQUFBLHFCQU1vQkcsZ0VBQWEsQ0FBQ0MsT0FBZCxDQUFzQkMsT0FBdEIsQ0FBOEJMLEVBQTlCLEVBQWtDTSxJQUFsQyxFQU5wQjs7QUFBQTtBQU1YUCx1QkFBUyxDQUFDQyxFQUFELENBQVQsQ0FBYyxPQUFkLENBTlc7QUFBQTtBQUFBLHFCQVFvQkcsZ0VBQWEsQ0FBQ0MsT0FBZCxDQUM1QkcsYUFENEIsQ0FDZFAsRUFEYyxFQUU1Qk0sSUFGNEIsRUFScEI7O0FBQUE7QUFRWFAsdUJBQVMsQ0FBQ0MsRUFBRCxDQUFULENBQWMsT0FBZCxDQVJXO0FBQUE7QUFBQTtBQUFBLHFCQWNIUSw2Q0FBSyxDQUFDQyxHQUFOLG1DQUFxQ1QsRUFBckMsWUFkRzs7QUFBQTtBQWVUSixvQkFBTSxDQUFDSSxFQUFELENBQU4sR0FBYSxJQUFiO0FBZlM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFpQlRKLG9CQUFNLENBQUNJLEVBQUQsQ0FBTixHQUFhLEtBQWI7O0FBakJTO0FBb0JYLG9CQUFLVSxRQUFMLENBQWM7QUFBRVgseUJBQVMsRUFBVEEsU0FBRjtBQUFhSCxzQkFBTSxFQUFOQTtBQUFiLGVBQWQ7O0FBcEJXO0FBRzZCSSxnQkFBRSxFQUgvQjtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSzs7O21NQXdCSixrQkFBT1csS0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDTFgsa0JBREssR0FDQVcsS0FBSyxDQUFDQyxNQUFOLENBQWFDLElBRGI7QUFFVEYscUJBQUssQ0FBQ0csY0FBTjs7QUFFQSxzQkFBS0osUUFBTCxDQUFjLFVBQUNLLFNBQUQsRUFBZTtBQUMzQixzQkFBSWxCLFVBQVUsR0FBR21CLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLEVBQWQsRUFBa0JGLFNBQVMsQ0FBQ2xCLFVBQTVCLENBQWpCO0FBQ0FBLDRCQUFVLENBQUNHLEVBQUQsQ0FBVixHQUFpQixJQUFqQjtBQUNBLHlCQUFPO0FBQUVILDhCQUFVLEVBQVZBO0FBQUYsbUJBQVA7QUFDRCxpQkFKRDs7QUFKUztBQUFBO0FBQUEsdUJBV0RNLGdFQUFhLENBQUNDLE9BQWQsQ0FBc0JjLFFBQXRCLENBQStCbEIsRUFBL0IsRUFBbUNtQixJQUFuQyxDQUF3QztBQUM1Q0Msc0JBQUksRUFBRXRDLGNBRHNDO0FBRTVDdUMsdUJBQUssRUFBRSxNQUFLQyxLQUFMLENBQVd2QixTQUFYLENBQXFCQyxFQUFyQixFQUF5QixPQUF6QjtBQUZxQyxpQkFBeEMsQ0FYQzs7QUFBQTtBQWdCUHVCLCtEQUFNLENBQUNDLFlBQVAsQ0FBb0IsU0FBcEI7QUFoQk87QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFtQlQsc0JBQUtkLFFBQUwsQ0FBYyxVQUFDSyxTQUFELEVBQWU7QUFDM0Isc0JBQUlsQixVQUFVLEdBQUdtQixNQUFNLENBQUNDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCRixTQUFTLENBQUNsQixVQUE1QixDQUFqQjtBQUNBQSw0QkFBVSxDQUFDRyxFQUFELENBQVYsR0FBaUIsS0FBakI7QUFDQSx5QkFBTztBQUFFSCw4QkFBVSxFQUFWQTtBQUFGLG1CQUFQO0FBQ0QsaUJBSkQ7O0FBbkJTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE87Ozs7Ozs7O21NQTBCRyxrQkFBTzRCLENBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQVlDLDRCQUFaLFNBQVlBLFlBQVo7O0FBQ1osc0JBQUtoQixRQUFMLENBQWM7QUFBRVosNkJBQVcsRUFBRTRCLFlBQVksQ0FBQ0MsTUFBYixHQUFzQjtBQUFyQyxpQkFBZDs7QUFEWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQXJFWUMsdURBQUksQ0FBQ0MsR0FBTCxDQUFTQyxXQUFULEU7OztBQUF4QmhELDhCLGtCQUFnRCxDO0FBRWhERCx3QkFBUSxHQUFHa0QsUUFBUSxDQUFDQyxjQUFULENBQXdCLFFBQXhCLENBQVg7QUFFTUMsNkIsR0FBZ0JDLFdBQVcsQ0FBQyxZQUFNO0FBQ3RDLHNCQUFJckQsUUFBUSxDQUFDc0QsS0FBVCxDQUFlQyxVQUFmLEtBQThCLFNBQWxDLEVBQTZDO0FBQzNDLDBCQUFJLENBQUMxQixRQUFMLENBQWM7QUFDWjJCLGtDQUFZLEVBQUUsSUFERjtBQUVaMUMsa0NBQVksRUFBRWQsUUFBUSxDQUFDeUQ7QUFGWCxxQkFBZDs7QUFJQUMsaUNBQWEsQ0FBQ04sYUFBRCxDQUFiO0FBQ0Q7QUFDRixpQkFSZ0MsRUFROUIsR0FSOEIsQztBQVVqQyxxQkFBS3ZCLFFBQUwsQ0FBYztBQUFFaEIseUJBQU8sRUFBRTtBQUFYLGlCQUFkO0FBRUEscUJBQUs4QyxZQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7bUNBeURhO0FBQ2IsVUFBSUMsS0FBSyxHQUFHLEVBQVo7QUFDQSxVQUFJQyxPQUFPLEdBQUcsRUFBZDs7QUFDQSxXQUFLLElBQUkxQyxFQUFFLEdBQUcsQ0FBZCxFQUFpQkEsRUFBRSxJQUFJLEtBQUtDLEtBQUwsQ0FBV0MsTUFBbEMsRUFBMENGLEVBQUUsRUFBNUMsRUFBZ0Q7QUFDOUMsWUFBSVYsYUFBYSxDQUFDcUQsT0FBZCxDQUFzQkMsTUFBTSxDQUFDNUMsRUFBRCxDQUE1QixJQUFvQyxDQUF4QyxFQUEyQztBQUN6QzBDLGlCQUFPLENBQUNHLElBQVIsQ0FBYTdDLEVBQWI7QUFDRDtBQUNGOztBQUVEeUMsV0FBSyxDQUFDSSxJQUFOLENBQ0UsS0FBS0MsU0FBTCxDQUFlL0QsTUFBZixDQURGLEVBRUUsS0FBSytELFNBQUwsQ0FBZTFELGNBQWYsQ0FGRixFQUdFLEtBQUswRCxTQUFMLENBQWVKLE9BQWYsQ0FIRjtBQU1BLGFBQU8sTUFBQyx1REFBRCxDQUFNLEtBQU47QUFBWSxtQkFBVyxFQUFFO0FBQXpCLFNBQTZCRCxLQUE3QixDQUFQO0FBQ0Q7Ozs4QkFFU00sRyxFQUFLO0FBQUE7O0FBQ2IsVUFBSU4sS0FBSyxHQUFHLEVBQVo7O0FBQ0EsV0FBSyxJQUFJTyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRCxHQUFHLENBQUM1RCxNQUF4QixFQUFnQzZELENBQUMsRUFBakMsRUFBcUM7QUFDbkMsWUFBSWhELEVBQUUsR0FBRytDLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFaO0FBRUFQLGFBQUssQ0FBQ0ksSUFBTixDQUNFLE1BQUMsdURBQUQ7QUFBTSxhQUFHLEVBQUU3QztBQUFYLFdBQ0csS0FBS3NCLEtBQUwsQ0FBV3ZCLFNBQVgsQ0FBcUJDLEVBQXJCLElBQ0MsS0FBS3NCLEtBQUwsQ0FBVzFCLE1BQVgsQ0FBa0JJLEVBQWxCLElBQ0VBLEVBQUUsSUFBSSxDQUFOLEdBQ0UsTUFBQyw2REFBRDtBQUFZLGtCQUFRLEVBQUUsS0FBS2lEO0FBQTNCLFdBQ0UsTUFBQyx3REFBRDtBQUFPLGFBQUcsa0NBQTJCakQsRUFBM0I7QUFBVixVQURGLENBREYsR0FLRSxNQUFDLHdEQUFEO0FBQU8sYUFBRyxrQ0FBMkJBLEVBQTNCO0FBQVYsVUFOSixHQVNFLE1BQUMsNERBQUQ7QUFDRSxtQkFBUyxFQUFDLFFBRFo7QUFFRSxlQUFLLEVBQUU7QUFDTGtELHNCQUFVLEVBQUUsaUJBRFA7QUFFTEMsb0JBQVEsRUFBRSxNQUZMO0FBR0xDLHNCQUFVLEVBQUUsTUFIUDtBQUlMQyx5QkFBYSxFQUFFO0FBSlY7QUFGVCxXQVNFLE1BQUMsOERBQUQ7QUFBVyxlQUFLLEVBQUVyRCxFQUFsQjtBQUFzQixjQUFJLEVBQUUsS0FBS3NCLEtBQUwsQ0FBV3hCO0FBQXZDLFVBVEYsQ0FWSCxHQXVCQyxNQUFDLDhEQUFEO0FBQWEsZUFBSztBQUFsQixXQUNFLE1BQUMsOERBQUQsQ0FBYSxLQUFiO0FBQ0UsZUFBSyxFQUFFO0FBQUU2QixrQkFBTSxFQUFFLEtBQUtMLEtBQUwsQ0FBV3hCLFdBQVgsR0FBeUI7QUFBbkM7QUFEVCxVQURGLENBeEJKLEVBOEJFLE1BQUMsdURBQUQsQ0FBTSxPQUFOLFFBQ0UsTUFBQyx1REFBRCxDQUFNLE1BQU4sUUFDR2YsTUFBTSxDQUFDNEQsT0FBUCxDQUFlQyxNQUFNLENBQUM1QyxFQUFELENBQXJCLEtBQThCLENBQTlCLEdBQ0csd0JBQXdCQSxFQUQzQixHQUVHWixjQUFjLENBQUN1RCxPQUFmLENBQXVCQyxNQUFNLENBQUM1QyxFQUFELENBQTdCLEtBQXNDLENBQXRDLEdBQ0EsdUJBQXVCQSxFQUFFLEdBQUdkLFlBQTVCLENBREEsR0FFQSxrQkFBa0JjLEVBQUUsR0FBR1IsbUJBQXZCLENBTE4sQ0FERixFQVNHLEtBQUs4QixLQUFMLENBQVd2QixTQUFYLENBQXFCQyxFQUFyQixJQUNDLG1CQUNFLE1BQUMsdURBQUQsQ0FBTSxXQUFOLFFBQ0UsaUJBQ0dzRCxNQUFNLENBQUMsS0FBS2hDLEtBQUwsQ0FBV3ZCLFNBQVgsQ0FBcUJDLEVBQXJCLEVBQXlCLE9BQXpCLENBQUQsQ0FBTixHQUNHLGtCQUNBNEIsdURBQUksQ0FBQzJCLEtBQUwsQ0FBV0MsT0FBWCxDQUNFLEtBQUtsQyxLQUFMLENBQVd2QixTQUFYLENBQXFCQyxFQUFyQixFQUF5QixPQUF6QixDQURGLEVBRUUsT0FGRixDQURBLEdBS0EsTUFOSCxHQU9HLG9CQVJOLENBREYsQ0FERixFQWFFLE1BQUMsdURBQUQsQ0FBTSxJQUFOO0FBQVcsZUFBSyxFQUFFO0FBQUVtRCxvQkFBUSxFQUFFLE1BQVo7QUFBb0JNLG9CQUFRLEVBQUU7QUFBOUI7QUFBbEIsb0JBRUczRSxjQUFjLElBQUksS0FBS3dDLEtBQUwsQ0FBV3ZCLFNBQVgsQ0FBcUJDLEVBQXJCLEVBQXlCLE9BQXpCLENBQWxCLEdBQ0M7QUFBRyxlQUFLLEVBQUU7QUFBRTBELGlCQUFLLEVBQUU7QUFBVDtBQUFWLG9CQURELEdBR0MsRUFMSixRQU9LLEtBQUtwQyxLQUFMLENBQVd2QixTQUFYLENBQXFCQyxFQUFyQixFQUF5QixPQUF6QixDQVBMLENBYkYsQ0FERCxHQXlCQyxNQUFDLDhEQUFEO0FBQWEsZUFBSyxFQUFFO0FBQUUyRCxxQkFBUyxFQUFFO0FBQWI7QUFBcEIsV0FDRSxNQUFDLDhEQUFELENBQWEsTUFBYixRQUNFLE1BQUMsOERBQUQsQ0FBYSxJQUFiO0FBQWtCLGdCQUFNLEVBQUM7QUFBekIsVUFERixFQUVFLE1BQUMsOERBQUQsQ0FBYSxJQUFiO0FBQWtCLGdCQUFNLEVBQUM7QUFBekIsVUFGRixDQURGLEVBS0UsTUFBQyw4REFBRCxDQUFhLFNBQWIsUUFDRSxNQUFDLDhEQUFELENBQWEsSUFBYjtBQUFrQixnQkFBTSxFQUFDO0FBQXpCLFVBREYsQ0FMRixDQWxDSixDQTlCRixFQTRFRSxNQUFDLHVEQUFELENBQU0sT0FBTjtBQUFjLGVBQUs7QUFBbkIsV0FDRSxNQUFDLDZDQUFEO0FBQU0sZUFBSyxtQkFBWTNELEVBQVo7QUFBWCxXQUNFO0FBQ0UsaUJBQU8sRUFBRSxtQkFBTTtBQUNiLGtCQUFJLENBQUNVLFFBQUwsQ0FBYztBQUFFaEIscUJBQU8sRUFBRTtBQUFYLGFBQWQ7QUFDRDtBQUhILFdBS0UsTUFBQyx5REFBRCx3QkFFRSxNQUFDLHVEQUFEO0FBQU0sY0FBSSxFQUFDO0FBQVgsVUFGRixDQUxGLENBREYsQ0FERixFQWNHLEtBQUs0QixLQUFMLENBQVd2QixTQUFYLENBQXFCQyxFQUFyQixJQUNDc0QsTUFBTSxDQUFDLEtBQUtoQyxLQUFMLENBQVd2QixTQUFYLENBQXFCQyxFQUFyQixFQUF5QixPQUF6QixDQUFELENBQU4sSUFDQSxLQUFLc0IsS0FBTCxDQUFXdkIsU0FBWCxDQUFxQkMsRUFBckIsRUFBeUIsT0FBekIsS0FBcUNsQixjQURyQyxHQUVFLE1BQUMseURBQUQ7QUFDRSxjQUFJLEVBQUVrQixFQURSO0FBRUUsaUJBQU8sTUFGVDtBQUdFLGlCQUFPLEVBQUUsS0FBS2tCLFFBSGhCO0FBSUUsaUJBQU8sRUFBRSxLQUFLSSxLQUFMLENBQVd6QixVQUFYLENBQXNCRyxFQUF0QixDQUpYO0FBS0Usa0JBQVEsRUFBRSxLQUFLc0IsS0FBTCxDQUFXekIsVUFBWCxDQUFzQkcsRUFBdEIsQ0FMWjtBQU1FLGVBQUssRUFBRTtBQUFFMkQscUJBQVMsRUFBRTtBQUFiO0FBTlQsd0JBU0UsTUFBQyx1REFBRDtBQUFNLGNBQUksRUFBQztBQUFYLFVBVEYsQ0FGRixHQWNFLEVBZkgsR0FrQkMsRUFoQ0osQ0E1RUYsQ0FERjtBQWtIRDs7QUFFRCxhQUFPbEIsS0FBUDtBQUNEOzs7NkJBRVE7QUFDUCxhQUNFLE1BQUMsMkRBQUQ7QUFBUSxlQUFPLEVBQUUsS0FBS25CLEtBQUwsQ0FBVzVCO0FBQTVCLFNBQ0UsTUFBQyxpREFBRCxRQUNFLDREQURGLEVBRUU7QUFDRSxZQUFJLEVBQUMsYUFEUDtBQUVFLGVBQU8sRUFBQztBQUZWLFFBRkYsRUFNRTtBQUFNLFlBQUksRUFBQyxRQUFYO0FBQW9CLGVBQU8sRUFBQztBQUE1QixRQU5GLENBREYsRUFTRSxNQUFDLDZEQUFELE9BVEYsRUFXRSxNQUFDLDREQUFEO0FBQ0UsaUJBQVMsRUFBQyxRQURaO0FBRUUsYUFBSyxFQUFFO0FBQ0xpRSxtQkFBUyxFQUFFLEtBQUtyQyxLQUFMLENBQVczQixZQUFYLEdBQTBCO0FBRGhDO0FBRlQsU0FNRSxNQUFDLHlEQUFEO0FBQVEsVUFBRSxFQUFDLElBQVg7QUFBZ0IsZ0JBQVEsTUFBeEI7QUFBeUIsZ0JBQVE7QUFBakMsaUNBQ3VCLEtBQUtNLEtBQUwsQ0FBV0MsTUFEbEMsc0JBTkYsRUFTRyxLQUFLMEQsWUFBTCxFQVRILENBWEYsQ0FERjtBQXlCRDs7Ozs7Ozs7Ozs7dUJBdFBzQnpELGdFQUFhLENBQUNDLE9BQWQsQ0FBc0J5RCxXQUF0QixHQUFvQ3ZELElBQXBDLEU7OztBQUFmSixzQjtrREFDQztBQUFFQSx3QkFBTSxFQUFOQTtBQUFGLGlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBWmE0RCwrQzs7QUFvUVRyRSx3RUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy90b2tlbnMuYmYwZTc3N2JkODUxY2NjODZiZmQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IExheW91dCBmcm9tICcuLi8uLi9jb21wb25lbnRzL0xheW91dCc7XHJcbmltcG9ydCB7XHJcbiAgQ29udGFpbmVyLFxyXG4gIEhlYWRlcixcclxuICBDYXJkLFxyXG4gIEljb24sXHJcbiAgQnV0dG9uLFxyXG4gIEltYWdlLFxyXG4gIFZpc2liaWxpdHksXHJcbiAgUGxhY2Vob2xkZXIsXHJcbn0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnO1xyXG5pbXBvcnQgY3J5cHRvQnl0ZTcyMSBmcm9tICcuLi8uLi9ldGhlcmV1bS9jcnlwdG9CeXRlNzIxJztcclxuaW1wb3J0IHsgTGluaywgUm91dGVyIH0gZnJvbSAnLi4vLi4vcm91dGVzJztcclxuaW1wb3J0IHdlYjMgZnJvbSAnLi4vLi4vZXRoZXJldW0vd2ViMyc7XHJcbmltcG9ydCBKZGVudGljb24gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9KZGVudGljb24nO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xyXG5pbXBvcnQgTU1Qcm9tcHQgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9NTVByb21wdCc7XHJcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XHJcblxyXG5sZXQgaGVhZGVyRWw7XHJcbmxldCBjdXJyZW50QWNjb3VudDtcclxubGV0IHZpa2luZyA9IHByb2Nlc3MuZW52LlZJS0lOR19BTU9VTlQuc3BsaXQoJywnKTtcclxubGV0IHZpa2luZ0Ftb3VudCA9IHZpa2luZy5sZW5ndGg7XHJcbmxldCBzcGVjaWFsRWRpdGlvbiA9IHByb2Nlc3MuZW52LlNQRUNJQUxfRURJVElPTi5zcGxpdCgnLCcpO1xyXG5sZXQgc3BlY2lhbEVkaXRpb25BbW91bnQgPSBzcGVjaWFsRWRpdGlvbi5sZW5ndGg7XHJcbmxldCBzcGVjaWFsVG9rZW5zID0gdmlraW5nLmNvbmNhdChzcGVjaWFsRWRpdGlvbik7XHJcbmxldCBzcGVjaWFsVG9rZW5zQW1vdW50ID0gdmlraW5nQW1vdW50ICsgc3BlY2lhbEVkaXRpb25BbW91bnQ7XHJcblxyXG5jbGFzcyBBbGxUb2tlbnMgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gIHN0YXRlID0ge1xyXG4gICAgbW91bnRlZDogZmFsc2UsXHJcbiAgICBoZWFkZXJIZWlnaHQ6IDAsXHJcbiAgICBpbWFnZXM6IHt9LFxyXG4gICAgYnV5TG9hZGluZzoge30sXHJcbiAgICBqZGVudEhlaWd0aDogMTc0LFxyXG4gICAgdG9rZW5JbmZvOiB7fSxcclxuICB9O1xyXG5cclxuICBzdGF0aWMgYXN5bmMgZ2V0SW5pdGlhbFByb3BzKCkge1xyXG4gICAgY29uc3Qgc3VwcGx5ID0gYXdhaXQgY3J5cHRvQnl0ZTcyMS5tZXRob2RzLnRvdGFsU3VwcGx5KCkuY2FsbCgpO1xyXG4gICAgcmV0dXJuIHsgc3VwcGx5IH07XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb21wb25lbnREaWRNb3VudCgpIHtcclxuICAgIGN1cnJlbnRBY2NvdW50ID0gKGF3YWl0IHdlYjMuZXRoLmdldEFjY291bnRzKCkpWzBdO1xyXG5cclxuICAgIGhlYWRlckVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2hlYWRlcicpO1xyXG5cclxuICAgIGNvbnN0IGhlYWRlclZpc2libGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGlmIChoZWFkZXJFbC5zdHlsZS52aXNpYmlsaXR5ID09PSAndmlzaWJsZScpIHtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgIHRyYW5zVmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgIGhlYWRlckhlaWdodDogaGVhZGVyRWwuY2xpZW50SGVpZ2h0LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNsZWFySW50ZXJ2YWwoaGVhZGVyVmlzaWJsZSk7XHJcbiAgICAgIH1cclxuICAgIH0sIDEwMCk7XHJcblxyXG4gICAgdGhpcy5zZXRTdGF0ZSh7IG1vdW50ZWQ6IHRydWUgfSk7XHJcblxyXG4gICAgdGhpcy5nZXRUb2tlbkluZm8oKTtcclxuICB9XHJcblxyXG4gIGdldFRva2VuSW5mbyA9IGFzeW5jICgpID0+IHtcclxuICAgIGxldCB0b2tlbkluZm8gPSB7fTtcclxuICAgIGxldCBpbWFnZXMgPSB7fTtcclxuICAgIGZvciAobGV0IGlkID0gMTsgaWQgPD0gdGhpcy5wcm9wcy5zdXBwbHk7IGlkKyspIHtcclxuICAgICAgdG9rZW5JbmZvW2lkXSA9IHt9O1xyXG5cclxuICAgICAgdG9rZW5JbmZvW2lkXVsnb3duZXInXSA9IGF3YWl0IGNyeXB0b0J5dGU3MjEubWV0aG9kcy5vd25lck9mKGlkKS5jYWxsKCk7XHJcblxyXG4gICAgICB0b2tlbkluZm9baWRdWydwcmljZSddID0gYXdhaXQgY3J5cHRvQnl0ZTcyMS5tZXRob2RzXHJcbiAgICAgICAgLmdldFRva2VuUHJpY2UoaWQpXHJcbiAgICAgICAgLmNhbGwoKTtcclxuXHJcbiAgICAgIC8vIGNoZWNrIGlmIHRva2VuIGhhcyBpbWFnZSBhbmQgc2F2ZSBpdCBpbiBzdGF0ZVxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGF4aW9zLmdldChgLi4vc3RhdGljL2ltYWdlcy9FUkM3MjEvJHtpZH1fdy5qcGdgKTtcclxuICAgICAgICBpbWFnZXNbaWRdID0gdHJ1ZTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBpbWFnZXNbaWRdID0gZmFsc2U7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyB0b2tlbkluZm8sIGltYWdlcyB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBidXlUb2tlbiA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgdmFyIGlkID0gZXZlbnQudGFyZ2V0Lm5hbWU7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIHRoaXMuc2V0U3RhdGUoKHByZXZTdGF0ZSkgPT4ge1xyXG4gICAgICBsZXQgYnV5TG9hZGluZyA9IE9iamVjdC5hc3NpZ24oe30sIHByZXZTdGF0ZS5idXlMb2FkaW5nKTtcclxuICAgICAgYnV5TG9hZGluZ1tpZF0gPSB0cnVlO1xyXG4gICAgICByZXR1cm4geyBidXlMb2FkaW5nIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBjcnlwdG9CeXRlNzIxLm1ldGhvZHMuYnV5VG9rZW4oaWQpLnNlbmQoe1xyXG4gICAgICAgIGZyb206IGN1cnJlbnRBY2NvdW50LFxyXG4gICAgICAgIHZhbHVlOiB0aGlzLnN0YXRlLnRva2VuSW5mb1tpZF1bJ3ByaWNlJ10sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgUm91dGVyLnJlcGxhY2VSb3V0ZSgnL3Rva2VucycpO1xyXG4gICAgfSBjYXRjaCB7fVxyXG5cclxuICAgIHRoaXMuc2V0U3RhdGUoKHByZXZTdGF0ZSkgPT4ge1xyXG4gICAgICBsZXQgYnV5TG9hZGluZyA9IE9iamVjdC5hc3NpZ24oe30sIHByZXZTdGF0ZS5idXlMb2FkaW5nKTtcclxuICAgICAgYnV5TG9hZGluZ1tpZF0gPSBmYWxzZTtcclxuICAgICAgcmV0dXJuIHsgYnV5TG9hZGluZyB9O1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgdXBkYXRlSW1hZ2UgPSBhc3luYyAoZSwgeyBjYWxjdWxhdGlvbnMgfSkgPT4ge1xyXG4gICAgdGhpcy5zZXRTdGF0ZSh7IGpkZW50SGVpZ3RoOiBjYWxjdWxhdGlvbnMuaGVpZ2h0IC0gNDAgfSk7XHJcbiAgfTtcclxuXHJcbiAgcmVuZGVyVG9rZW5zKCkge1xyXG4gICAgbGV0IGl0ZW1zID0gW107XHJcbiAgICBsZXQgY2xhc3NpYyA9IFtdO1xyXG4gICAgZm9yIChsZXQgaWQgPSAxOyBpZCA8PSB0aGlzLnByb3BzLnN1cHBseTsgaWQrKykge1xyXG4gICAgICBpZiAoc3BlY2lhbFRva2Vucy5pbmRleE9mKFN0cmluZyhpZCkpIDwgMCkge1xyXG4gICAgICAgIGNsYXNzaWMucHVzaChpZCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpdGVtcy5wdXNoKFxyXG4gICAgICB0aGlzLm1ha2VDYXJkcyh2aWtpbmcpLFxyXG4gICAgICB0aGlzLm1ha2VDYXJkcyhzcGVjaWFsRWRpdGlvbiksXHJcbiAgICAgIHRoaXMubWFrZUNhcmRzKGNsYXNzaWMpXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiA8Q2FyZC5Hcm91cCBpdGVtc1BlclJvdz17M30+e2l0ZW1zfTwvQ2FyZC5Hcm91cD47XHJcbiAgfVxyXG5cclxuICBtYWtlQ2FyZHMoaWRzKSB7XHJcbiAgICBsZXQgaXRlbXMgPSBbXTtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaWRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGxldCBpZCA9IGlkc1tpXTtcclxuXHJcbiAgICAgIGl0ZW1zLnB1c2goXHJcbiAgICAgICAgPENhcmQga2V5PXtpZH0+XHJcbiAgICAgICAgICB7dGhpcy5zdGF0ZS50b2tlbkluZm9baWRdID8gKFxyXG4gICAgICAgICAgICB0aGlzLnN0YXRlLmltYWdlc1tpZF0gPyAoXHJcbiAgICAgICAgICAgICAgaWQgPT0gMSA/IChcclxuICAgICAgICAgICAgICAgIDxWaXNpYmlsaXR5IG9uVXBkYXRlPXt0aGlzLnVwZGF0ZUltYWdlfT5cclxuICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17YC9zdGF0aWMvaW1hZ2VzL0VSQzcyMS8ke2lkfV93LmpwZ2B9IC8+XHJcbiAgICAgICAgICAgICAgICA8L1Zpc2liaWxpdHk+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2Avc3RhdGljL2ltYWdlcy9FUkM3MjEvJHtpZH1fdy5qcGdgfSAvPlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q29udGFpbmVyXHJcbiAgICAgICAgICAgICAgICB0ZXh0QWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMCwwLDAsLjA1KScsXHJcbiAgICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnYXV0bycsXHJcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmdUb3A6ICcyMHB4JyxcclxuICAgICAgICAgICAgICAgICAgcGFkZGluZ0JvdHRvbTogJzIwcHgnLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SmRlbnRpY29uIHZhbHVlPXtpZH0gc2l6ZT17dGhpcy5zdGF0ZS5qZGVudEhlaWd0aH0gLz5cclxuICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPFBsYWNlaG9sZGVyIGZsdWlkPlxyXG4gICAgICAgICAgICAgIDxQbGFjZWhvbGRlci5JbWFnZVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiB0aGlzLnN0YXRlLmpkZW50SGVpZ3RoICsgNDAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L1BsYWNlaG9sZGVyPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxDYXJkLkNvbnRlbnQ+XHJcbiAgICAgICAgICAgIDxDYXJkLkhlYWRlcj5cclxuICAgICAgICAgICAgICB7dmlraW5nLmluZGV4T2YoU3RyaW5nKGlkKSkgPj0gMFxyXG4gICAgICAgICAgICAgICAgPyAnVmlraW5nIENvbGxlY3Rpb24gIycgKyBpZFxyXG4gICAgICAgICAgICAgICAgOiBzcGVjaWFsRWRpdGlvbi5pbmRleE9mKFN0cmluZyhpZCkpID49IDBcclxuICAgICAgICAgICAgICAgID8gJ1NwZWNpYWwgRWRpdGlvbiAjJyArIChpZCAtIHZpa2luZ0Ftb3VudClcclxuICAgICAgICAgICAgICAgIDogJ0NSQkMgVG9rZW4gIycgKyAoaWQgLSBzcGVjaWFsVG9rZW5zQW1vdW50KX1cclxuICAgICAgICAgICAgPC9DYXJkLkhlYWRlcj5cclxuXHJcbiAgICAgICAgICAgIHt0aGlzLnN0YXRlLnRva2VuSW5mb1tpZF0gPyAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxDYXJkLkRlc2NyaXB0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8Yj5cclxuICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKHRoaXMuc3RhdGUudG9rZW5JbmZvW2lkXVsncHJpY2UnXSlcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ1Rva2VuIHByaWNlOiAnICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2ViMy51dGlscy5mcm9tV2VpKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUudG9rZW5JbmZvW2lkXVsncHJpY2UnXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAnZXRoZXInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAnIEVUSCdcclxuICAgICAgICAgICAgICAgICAgICAgIDogJ1Rva2VuIG5vdCBmb3Igc2FsZSd9XHJcbiAgICAgICAgICAgICAgICAgIDwvYj5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZC5EZXNjcmlwdGlvbj5cclxuICAgICAgICAgICAgICAgIDxDYXJkLk1ldGEgc3R5bGU9e3sgb3ZlcmZsb3c6ICdhdXRvJywgZm9udFNpemU6ICcwLjllbScgfX0+XHJcbiAgICAgICAgICAgICAgICAgIE93bmVyXHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50QWNjb3VudCA9PSB0aGlzLnN0YXRlLnRva2VuSW5mb1tpZF1bJ293bmVyJ10gPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGIgc3R5bGU9e3sgY29sb3I6ICdyZ2JhKDAsMCwwLC42OCknIH19PiAoWW91KTwvYj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAnJ1xyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA6IHt0aGlzLnN0YXRlLnRva2VuSW5mb1tpZF1bJ293bmVyJ119XHJcbiAgICAgICAgICAgICAgICA8L0NhcmQuTWV0YT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8UGxhY2Vob2xkZXIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMTBweCcgfX0+XHJcbiAgICAgICAgICAgICAgICA8UGxhY2Vob2xkZXIuSGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgICA8UGxhY2Vob2xkZXIuTGluZSBsZW5ndGg9XCJ2ZXJ5IHNob3J0XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPFBsYWNlaG9sZGVyLkxpbmUgbGVuZ3RoPVwibWVkaXVtXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvUGxhY2Vob2xkZXIuSGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgPFBsYWNlaG9sZGVyLlBhcmFncmFwaD5cclxuICAgICAgICAgICAgICAgICAgPFBsYWNlaG9sZGVyLkxpbmUgbGVuZ3RoPVwic2hvcnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9QbGFjZWhvbGRlci5QYXJhZ3JhcGg+XHJcbiAgICAgICAgICAgICAgPC9QbGFjZWhvbGRlcj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvQ2FyZC5Db250ZW50PlxyXG5cclxuICAgICAgICAgIDxDYXJkLkNvbnRlbnQgZXh0cmE+XHJcbiAgICAgICAgICAgIDxMaW5rIHJvdXRlPXtgL3Rva2VuLyR7aWR9YH0+XHJcbiAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IG1vdW50ZWQ6IGZhbHNlIH0pO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImNoZXZyb24gY2lyY2xlIHJpZ2h0XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAge3RoaXMuc3RhdGUudG9rZW5JbmZvW2lkXSA/IChcclxuICAgICAgICAgICAgICBOdW1iZXIodGhpcy5zdGF0ZS50b2tlbkluZm9baWRdWydwcmljZSddKSAmJlxyXG4gICAgICAgICAgICAgIHRoaXMuc3RhdGUudG9rZW5JbmZvW2lkXVsnb3duZXInXSAhPSBjdXJyZW50QWNjb3VudCA/IChcclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgbmFtZT17aWR9XHJcbiAgICAgICAgICAgICAgICAgIHByaW1hcnlcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17dGhpcy5idXlUb2tlbn1cclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17dGhpcy5zdGF0ZS5idXlMb2FkaW5nW2lkXX1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RoaXMuc3RhdGUuYnV5TG9hZGluZ1tpZF19XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpblRvcDogJzVweCcgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQnV5IHRva2VuXHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJzaG9wcGluZyBjYXJ0IHJpZ2h0XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAnJ1xyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAnJ1xyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9DYXJkLkNvbnRlbnQ+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpdGVtcztcclxuICB9XHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxMYXlvdXQgbW91bnRlZD17dGhpcy5zdGF0ZS5tb3VudGVkfT5cclxuICAgICAgICA8SGVhZD5cclxuICAgICAgICAgIDx0aXRsZT5DcnlwdG8gQnl0ZSBDb2xsZWN0aWJsZSAtIEFsbCBUb2tlbnM8L3RpdGxlPlxyXG4gICAgICAgICAgPG1ldGFcclxuICAgICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgY29udGVudD1cIlZpZXcgYWxsIGV4aXN0aW5nIENyeXB0byBCeXRlIENvbGxlY3RpYmxlIHRva2VucyBhbmQgYnV5IHRoZSBvbmVzIHRoYXQgYXJlIHVwIGZvciBzYWxlLlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPG1ldGEgbmFtZT1cInJvYm90c1wiIGNvbnRlbnQ9XCJpbmRleCwgZm9sbG93XCIgLz5cclxuICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgPE1NUHJvbXB0IC8+XHJcblxyXG4gICAgICAgIDxDb250YWluZXJcclxuICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IHRoaXMuc3RhdGUuaGVhZGVySGVpZ2h0ICsgMjAsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxIZWFkZXIgYXM9XCJoMlwiIGRpdmlkaW5nIGludmVydGVkPlxyXG4gICAgICAgICAgICBUaGVyZSBhcmUgY3VycmVudGx5IHt0aGlzLnByb3BzLnN1cHBseX0gZXhpc3RpbmcgdG9rZW5zLlxyXG4gICAgICAgICAgPC9IZWFkZXI+XHJcbiAgICAgICAgICB7dGhpcy5yZW5kZXJUb2tlbnMoKX1cclxuICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgPC9MYXlvdXQ+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWxsVG9rZW5zO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9