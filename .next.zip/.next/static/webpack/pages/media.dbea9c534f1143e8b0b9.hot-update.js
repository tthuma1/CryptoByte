webpackHotUpdate_N_E("pages/media",{

/***/ "./pages/media.js":
/*!************************!*\
  !*** ./pages/media.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! next/head */ "./node_modules/next/dist/next-server/lib/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_12__);









var __jsx = react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }





var headerEl;

var Media = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(Media, _Component);

  var _super = _createSuper(Media);

  function Media() {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Media);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "state", {
      mounted: false,
      headerHeight: 0
    });

    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(Media, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var _this2 = this;

        var headerVisible;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                headerEl = document.getElementById('header');
                headerVisible = setInterval(function () {
                  if (headerEl.style.visibility === 'visible') {
                    _this2.setState({
                      headerHeight: headerEl.clientHeight
                    });

                    clearInterval(headerVisible);
                  }
                }, 100);
                this.setState({
                  mounted: true
                });

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "render",
    value: function render() {
      return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_10__["default"], {
        mounted: this.state.mounted
      }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_12___default.a, null, __jsx("title", null, "Crypto Byte Collectible - Sell Tokens"), __jsx("meta", {
        name: "description",
        content: "Media related to Crypto Byte Collectible tokens."
      }), __jsx("meta", {
        name: "robots",
        content: "index, follow"
      })), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Container"], {
        textAlign: "center",
        style: {
          marginTop: this.state.headerHeight + 20,
          color: 'rgba(255,255,255,.9)'
        }
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_11__["Header"], {
        as: "h2",
        dividing: true,
        inverted: true
      }, "How Crypto Byte Collectible tokens are made."), __jsx("video", {
        height: "450",
        controls: true,
        style: {
          marginBottom: '5vh'
        }
      }, __jsx("source", {
        src: "/static/videos/film_crbc.mp4",
        type: "video/mp4"
      })), __jsx("img", {
        src: "/static/images/custom-design.jpg",
        height: "400",
        style: {
          marginBottom: '5vh'
        }
      }), __jsx("br", null), __jsx("img", {
        src: "/static/images/comic.jpg",
        height: "700"
      })));
    }
  }]);

  return Media;
}(react__WEBPACK_IMPORTED_MODULE_9__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Media);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvbWVkaWEuanMiXSwibmFtZXMiOlsiaGVhZGVyRWwiLCJNZWRpYSIsIm1vdW50ZWQiLCJoZWFkZXJIZWlnaHQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiaGVhZGVyVmlzaWJsZSIsInNldEludGVydmFsIiwic3R5bGUiLCJ2aXNpYmlsaXR5Iiwic2V0U3RhdGUiLCJjbGllbnRIZWlnaHQiLCJjbGVhckludGVydmFsIiwic3RhdGUiLCJtYXJnaW5Ub3AiLCJjb2xvciIsIm1hcmdpbkJvdHRvbSIsIkNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFJQSxRQUFKOztJQUVNQyxLOzs7Ozs7Ozs7Ozs7Ozs7O2dOQUNJO0FBQ05DLGFBQU8sRUFBRSxLQURIO0FBRU5DLGtCQUFZLEVBQUU7QUFGUixLOzs7Ozs7Ozs7Ozs7Ozs7O0FBTU5ILHdCQUFRLEdBQUdJLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixRQUF4QixDQUFYO0FBRU1DLDZCLEdBQWdCQyxXQUFXLENBQUMsWUFBTTtBQUN0QyxzQkFBSVAsUUFBUSxDQUFDUSxLQUFULENBQWVDLFVBQWYsS0FBOEIsU0FBbEMsRUFBNkM7QUFDM0MsMEJBQUksQ0FBQ0MsUUFBTCxDQUFjO0FBQ1pQLGtDQUFZLEVBQUVILFFBQVEsQ0FBQ1c7QUFEWCxxQkFBZDs7QUFHQUMsaUNBQWEsQ0FBQ04sYUFBRCxDQUFiO0FBQ0Q7QUFDRixpQkFQZ0MsRUFPOUIsR0FQOEIsQztBQVNqQyxxQkFBS0ksUUFBTCxDQUFjO0FBQUVSLHlCQUFPLEVBQUU7QUFBWCxpQkFBZDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzZCQUdPO0FBQ1AsYUFDRSxNQUFDLDJEQUFEO0FBQVEsZUFBTyxFQUFFLEtBQUtXLEtBQUwsQ0FBV1g7QUFBNUIsU0FDRSxNQUFDLGlEQUFELFFBQ0UsNkRBREYsRUFFRTtBQUNFLFlBQUksRUFBQyxhQURQO0FBRUUsZUFBTyxFQUFDO0FBRlYsUUFGRixFQU1FO0FBQU0sWUFBSSxFQUFDLFFBQVg7QUFBb0IsZUFBTyxFQUFDO0FBQTVCLFFBTkYsQ0FERixFQVVFLE1BQUMsNERBQUQ7QUFDRSxpQkFBUyxFQUFDLFFBRFo7QUFFRSxhQUFLLEVBQUU7QUFDTFksbUJBQVMsRUFBRSxLQUFLRCxLQUFMLENBQVdWLFlBQVgsR0FBMEIsRUFEaEM7QUFFTFksZUFBSyxFQUFFO0FBRkY7QUFGVCxTQU9FLE1BQUMseURBQUQ7QUFBUSxVQUFFLEVBQUMsSUFBWDtBQUFnQixnQkFBUSxNQUF4QjtBQUF5QixnQkFBUTtBQUFqQyx3REFQRixFQVdFO0FBQU8sY0FBTSxFQUFDLEtBQWQ7QUFBb0IsZ0JBQVEsTUFBNUI7QUFBNkIsYUFBSyxFQUFFO0FBQUVDLHNCQUFZLEVBQUU7QUFBaEI7QUFBcEMsU0FDRTtBQUFRLFdBQUcsRUFBQyw4QkFBWjtBQUEyQyxZQUFJLEVBQUM7QUFBaEQsUUFERixDQVhGLEVBZUU7QUFDRSxXQUFHLEVBQUMsa0NBRE47QUFFRSxjQUFNLEVBQUMsS0FGVDtBQUdFLGFBQUssRUFBRTtBQUNMQSxzQkFBWSxFQUFFO0FBRFQ7QUFIVCxRQWZGLEVBdUJFLGlCQXZCRixFQXlCRTtBQUFLLFdBQUcsRUFBQywwQkFBVDtBQUFvQyxjQUFNLEVBQUM7QUFBM0MsUUF6QkYsQ0FWRixDQURGO0FBd0NEOzs7O0VBOURpQkMsK0M7O0FBaUVMaEIsb0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbWVkaWEuZGJlYTljNTM0ZjExNDNlOGIwYjkuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSAnLi4vY29tcG9uZW50cy9MYXlvdXQnO1xyXG5pbXBvcnQgeyBDb250YWluZXIsIEhlYWRlciB9IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0JztcclxuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcclxuXHJcbmxldCBoZWFkZXJFbDtcclxuXHJcbmNsYXNzIE1lZGlhIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICBzdGF0ZSA9IHtcclxuICAgIG1vdW50ZWQ6IGZhbHNlLFxyXG4gICAgaGVhZGVySGVpZ2h0OiAwLFxyXG4gIH07XHJcblxyXG4gIGFzeW5jIGNvbXBvbmVudERpZE1vdW50KCkge1xyXG4gICAgaGVhZGVyRWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaGVhZGVyJyk7XHJcblxyXG4gICAgY29uc3QgaGVhZGVyVmlzaWJsZSA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgaWYgKGhlYWRlckVsLnN0eWxlLnZpc2liaWxpdHkgPT09ICd2aXNpYmxlJykge1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgaGVhZGVySGVpZ2h0OiBoZWFkZXJFbC5jbGllbnRIZWlnaHQsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2xlYXJJbnRlcnZhbChoZWFkZXJWaXNpYmxlKTtcclxuICAgICAgfVxyXG4gICAgfSwgMTAwKTtcclxuXHJcbiAgICB0aGlzLnNldFN0YXRlKHsgbW91bnRlZDogdHJ1ZSB9KTtcclxuICB9XHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxMYXlvdXQgbW91bnRlZD17dGhpcy5zdGF0ZS5tb3VudGVkfT5cclxuICAgICAgICA8SGVhZD5cclxuICAgICAgICAgIDx0aXRsZT5DcnlwdG8gQnl0ZSBDb2xsZWN0aWJsZSAtIFNlbGwgVG9rZW5zPC90aXRsZT5cclxuICAgICAgICAgIDxtZXRhXHJcbiAgICAgICAgICAgIG5hbWU9XCJkZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgIGNvbnRlbnQ9XCJNZWRpYSByZWxhdGVkIHRvIENyeXB0byBCeXRlIENvbGxlY3RpYmxlIHRva2Vucy5cIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxtZXRhIG5hbWU9XCJyb2JvdHNcIiBjb250ZW50PVwiaW5kZXgsIGZvbGxvd1wiIC8+XHJcbiAgICAgICAgPC9IZWFkPlxyXG5cclxuICAgICAgICA8Q29udGFpbmVyXHJcbiAgICAgICAgICB0ZXh0QWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgbWFyZ2luVG9wOiB0aGlzLnN0YXRlLmhlYWRlckhlaWdodCArIDIwLFxyXG4gICAgICAgICAgICBjb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsLjkpJyxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEhlYWRlciBhcz1cImgyXCIgZGl2aWRpbmcgaW52ZXJ0ZWQ+XHJcbiAgICAgICAgICAgIEhvdyBDcnlwdG8gQnl0ZSBDb2xsZWN0aWJsZSB0b2tlbnMgYXJlIG1hZGUuXHJcbiAgICAgICAgICA8L0hlYWRlcj5cclxuXHJcbiAgICAgICAgICA8dmlkZW8gaGVpZ2h0PVwiNDUwXCIgY29udHJvbHMgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnNXZoJyB9fT5cclxuICAgICAgICAgICAgPHNvdXJjZSBzcmM9XCIvc3RhdGljL3ZpZGVvcy9maWxtX2NyYmMubXA0XCIgdHlwZT1cInZpZGVvL21wNFwiIC8+XHJcbiAgICAgICAgICA8L3ZpZGVvPlxyXG5cclxuICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWFnZXMvY3VzdG9tLWRlc2lnbi5qcGdcIlxyXG4gICAgICAgICAgICBoZWlnaHQ9XCI0MDBcIlxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzV2aCcsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxiciAvPlxyXG5cclxuICAgICAgICAgIDxpbWcgc3JjPVwiL3N0YXRpYy9pbWFnZXMvY29taWMuanBnXCIgaGVpZ2h0PVwiNzAwXCIgLz5cclxuICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgPC9MYXlvdXQ+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWVkaWE7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=