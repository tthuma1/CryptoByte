webpackHotUpdate_N_E("pages/index",{

/***/ "./components/Header.js":
/*!******************************!*\
  !*** ./components/Header.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../ethereum/web3 */ "./ethereum/web3.js");
/* harmony import */ var _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../ethereum/cryptoByte721 */ "./ethereum/cryptoByte721.js");









var __jsx = react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_6__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }






var currentAccount;

var Header = /*#__PURE__*/function (_React$Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(Header, _React$Component);

  var _super = _createSuper(Header);

  function Header() {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Header);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this), "state", {
      isAdmin: 'none',
      visibleFull: 'hidden',
      pausedMounted: false,
      hasMounted: false
    });

    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(Header, [{
    key: "componentDidMount",
    value: function () {
      var _componentDidMount = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var _this2 = this;

        var isMinter, interval;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _ethereum_web3__WEBPACK_IMPORTED_MODULE_12__["default"].eth.getAccounts();

              case 2:
                currentAccount = _context.sent[0];
                _context.next = 5;
                return _ethereum_web3__WEBPACK_IMPORTED_MODULE_12__["default"].eth.net.getNetworkType();

              case 5:
                _context.t1 = _context.sent;
                _context.t2 = "main";
                _context.t0 = _context.t1 === _context.t2;

                if (!_context.t0) {
                  _context.next = 10;
                  break;
                }

                _context.t0 = typeof currentAccount !== 'undefined';

              case 10:
                if (!_context.t0) {
                  _context.next = 15;
                  break;
                }

                _context.next = 13;
                return _ethereum_cryptoByte721__WEBPACK_IMPORTED_MODULE_13__["default"].methods.isMinter(currentAccount).call();

              case 13:
                isMinter = _context.sent;

                if (isMinter) {
                  this.setState({
                    isAdmin: 'flex'
                  });
                }

              case 15:
                interval = setInterval(function () {
                  if (!_this2.state.hasMounted && _this2.props.mounted == true) {
                    _this2.props.updateState(true);

                    _this2.setState({
                      visibleFull: 'visible',
                      hasMounted: true
                    });
                  }

                  if (_this2.props.mounted == false) {
                    _this2.props.updateState(false);

                    _this2.setState({
                      visibleFull: 'hidden'
                    });
                  }
                }, 500);

              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function componentDidMount() {
        return _componentDidMount.apply(this, arguments);
      }

      return componentDidMount;
    }()
  }, {
    key: "hideAll",
    value: function hideAll() {
      this.setState({
        visibleFull: 'hidden'
      });
      this.props.updateState(false);
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return __jsx("div", null, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_10__["Menu"], {
        stackable: true,
        inverted: true,
        fixed: "top",
        id: "header",
        style: {
          visibility: this.state.visibleFull
        }
      }, __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        href: "/"
      }, __jsx("a", {
        className: "item"
      }, __jsx("img", {
        src: "/static/favicon2.png"
      }))), __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        href: "/"
      }, __jsx("a", {
        className: "item"
      }, "Home")), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_10__["Dropdown"], {
        item: true,
        text: "Collectible Tokens"
      }, __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_10__["Dropdown"].Menu, null, __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        href: "/tokens"
      }, __jsx("a", {
        className: "item",
        onClick: function onClick() {
          if (!(location.pathname == '/tokens')) {
            _this3.hideAll();
          } else {
            _this3.hideAll();

            location.reload();
          }
        }
      }, "All Tokens")), __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        href: "/tokens/".concat(currentAccount)
      }, __jsx("a", {
        className: "item",
        onClick: function onClick() {
          _this3.hideAll();
        }
      }, "My Tokens")), __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        href: "/create_tokens"
      }, __jsx("a", {
        className: "item"
      }, "Create New Tokens")))), __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        href: "/media"
      }, __jsx("a", {
        className: "item"
      }, "Media")), __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_10__["Menu"].Menu, {
        position: "right",
        style: {
          backgroundColor: '#444444',
          display: this.state.isAdmin
        }
      }, __jsx(_routes__WEBPACK_IMPORTED_MODULE_11__["Link"], {
        route: "/"
      }, __jsx("a", {
        className: "item"
      }, "Admin Page")))));
    }
  }]);

  return Header;
}(react__WEBPACK_IMPORTED_MODULE_9___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Header);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9IZWFkZXIuanMiXSwibmFtZXMiOlsiY3VycmVudEFjY291bnQiLCJIZWFkZXIiLCJpc0FkbWluIiwidmlzaWJsZUZ1bGwiLCJwYXVzZWRNb3VudGVkIiwiaGFzTW91bnRlZCIsIndlYjMiLCJldGgiLCJnZXRBY2NvdW50cyIsIm5ldCIsImdldE5ldHdvcmtUeXBlIiwicHJvY2VzcyIsImNyeXB0b0J5dGU3MjEiLCJtZXRob2RzIiwiaXNNaW50ZXIiLCJjYWxsIiwic2V0U3RhdGUiLCJpbnRlcnZhbCIsInNldEludGVydmFsIiwic3RhdGUiLCJwcm9wcyIsIm1vdW50ZWQiLCJ1cGRhdGVTdGF0ZSIsInZpc2liaWxpdHkiLCJsb2NhdGlvbiIsInBhdGhuYW1lIiwiaGlkZUFsbCIsInJlbG9hZCIsImJhY2tncm91bmRDb2xvciIsImRpc3BsYXkiLCJSZWFjdCIsIkNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFJQSxjQUFKOztJQUVNQyxNOzs7Ozs7Ozs7Ozs7Ozs7O2dOQUNJO0FBQ05DLGFBQU8sRUFBRSxNQURIO0FBRU5DLGlCQUFXLEVBQUUsUUFGUDtBQUdOQyxtQkFBYSxFQUFFLEtBSFQ7QUFJTkMsZ0JBQVUsRUFBRTtBQUpOLEs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQVFrQkMsdURBQUksQ0FBQ0MsR0FBTCxDQUFTQyxXQUFULEU7OztBQUF4QlIsOEIsaUJBQWdELEM7O3VCQUd2Q00sdURBQUksQ0FBQ0MsR0FBTCxDQUFTRSxHQUFULENBQWFDLGNBQWIsRTs7Ozs4QkFBbUNDLE07Ozs7Ozs7OzhCQUMxQyxPQUFPWCxjQUFQLEtBQTBCLFc7Ozs7Ozs7Ozt1QkFFSFksZ0VBQWEsQ0FBQ0MsT0FBZCxDQUNwQkMsUUFEb0IsQ0FDWGQsY0FEVyxFQUVwQmUsSUFGb0IsRTs7O0FBQWpCRCx3Qjs7QUFJTixvQkFBSUEsUUFBSixFQUFjO0FBQ1osdUJBQUtFLFFBQUwsQ0FBYztBQUFFZCwyQkFBTyxFQUFFO0FBQVgsbUJBQWQ7QUFDRDs7O0FBR0dlLHdCLEdBQVdDLFdBQVcsQ0FBQyxZQUFNO0FBQ2pDLHNCQUFJLENBQUMsTUFBSSxDQUFDQyxLQUFMLENBQVdkLFVBQVosSUFBMEIsTUFBSSxDQUFDZSxLQUFMLENBQVdDLE9BQVgsSUFBc0IsSUFBcEQsRUFBMEQ7QUFDeEQsMEJBQUksQ0FBQ0QsS0FBTCxDQUFXRSxXQUFYLENBQXVCLElBQXZCOztBQUNBLDBCQUFJLENBQUNOLFFBQUwsQ0FBYztBQUFFYixpQ0FBVyxFQUFFLFNBQWY7QUFBMEJFLGdDQUFVLEVBQUU7QUFBdEMscUJBQWQ7QUFDRDs7QUFFRCxzQkFBSSxNQUFJLENBQUNlLEtBQUwsQ0FBV0MsT0FBWCxJQUFzQixLQUExQixFQUFpQztBQUMvQiwwQkFBSSxDQUFDRCxLQUFMLENBQVdFLFdBQVgsQ0FBdUIsS0FBdkI7O0FBQ0EsMEJBQUksQ0FBQ04sUUFBTCxDQUFjO0FBQUViLGlDQUFXLEVBQUU7QUFBZixxQkFBZDtBQUNEO0FBQ0YsaUJBVjJCLEVBVXpCLEdBVnlCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs4QkFhcEI7QUFDUixXQUFLYSxRQUFMLENBQWM7QUFBRWIsbUJBQVcsRUFBRTtBQUFmLE9BQWQ7QUFDQSxXQUFLaUIsS0FBTCxDQUFXRSxXQUFYLENBQXVCLEtBQXZCO0FBQ0Q7Ozs2QkFFUTtBQUFBOztBQUNQLGFBQ0UsbUJBQ0UsTUFBQyx1REFBRDtBQUNFLGlCQUFTLE1BRFg7QUFFRSxnQkFBUSxNQUZWO0FBR0UsYUFBSyxFQUFDLEtBSFI7QUFJRSxVQUFFLEVBQUMsUUFKTDtBQUtFLGFBQUssRUFBRTtBQUNMQyxvQkFBVSxFQUFFLEtBQUtKLEtBQUwsQ0FBV2hCO0FBRGxCO0FBTFQsU0FTRSxNQUFDLDZDQUFEO0FBQU0sWUFBSSxFQUFDO0FBQVgsU0FDRTtBQUFHLGlCQUFTLEVBQUM7QUFBYixTQUNFO0FBQUssV0FBRyxFQUFDO0FBQVQsUUFERixDQURGLENBVEYsRUFjRSxNQUFDLDZDQUFEO0FBQU0sWUFBSSxFQUFDO0FBQVgsU0FDRTtBQUFHLGlCQUFTLEVBQUM7QUFBYixnQkFERixDQWRGLEVBaUJFLE1BQUMsMkRBQUQ7QUFBVSxZQUFJLE1BQWQ7QUFBZSxZQUFJLEVBQUM7QUFBcEIsU0FDRSxNQUFDLDJEQUFELENBQVUsSUFBVixRQUNFLE1BQUMsNkNBQUQ7QUFBTSxZQUFJLEVBQUM7QUFBWCxTQUNFO0FBQ0UsaUJBQVMsRUFBQyxNQURaO0FBRUUsZUFBTyxFQUFFLG1CQUFNO0FBQ2IsY0FBSSxFQUFFcUIsUUFBUSxDQUFDQyxRQUFULElBQXFCLFNBQXZCLENBQUosRUFBdUM7QUFDckMsa0JBQUksQ0FBQ0MsT0FBTDtBQUNELFdBRkQsTUFFTztBQUNMLGtCQUFJLENBQUNBLE9BQUw7O0FBQ0FGLG9CQUFRLENBQUNHLE1BQVQ7QUFDRDtBQUNGO0FBVEgsc0JBREYsQ0FERixFQWdCRSxNQUFDLDZDQUFEO0FBQU0sWUFBSSxvQkFBYTNCLGNBQWI7QUFBVixTQUNFO0FBQ0UsaUJBQVMsRUFBQyxNQURaO0FBRUUsZUFBTyxFQUFFLG1CQUFNO0FBQ2IsZ0JBQUksQ0FBQzBCLE9BQUw7QUFDRDtBQUpILHFCQURGLENBaEJGLEVBMEJFLE1BQUMsNkNBQUQ7QUFBTSxZQUFJLEVBQUM7QUFBWCxTQUNFO0FBQUcsaUJBQVMsRUFBQztBQUFiLDZCQURGLENBMUJGLENBREYsQ0FqQkYsRUFpREUsTUFBQyw2Q0FBRDtBQUFNLFlBQUksRUFBQztBQUFYLFNBQ0U7QUFBRyxpQkFBUyxFQUFDO0FBQWIsaUJBREYsQ0FqREYsRUFxREUsTUFBQyx1REFBRCxDQUFNLElBQU47QUFDRSxnQkFBUSxFQUFDLE9BRFg7QUFFRSxhQUFLLEVBQUU7QUFDTEUseUJBQWUsRUFBRSxTQURaO0FBRUxDLGlCQUFPLEVBQUUsS0FBS1YsS0FBTCxDQUFXakI7QUFGZjtBQUZULFNBT0UsTUFBQyw2Q0FBRDtBQUFNLGFBQUssRUFBQztBQUFaLFNBQ0U7QUFBRyxpQkFBUyxFQUFDO0FBQWIsc0JBREYsQ0FQRixDQXJERixDQURGLENBREY7QUFxRUQ7Ozs7RUFoSGtCNEIsNENBQUssQ0FBQ0MsUzs7QUFtSFo5QixxRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5mZTNhZGRiMWM2NDYwNzk5MjU4Zi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTWVudSwgRHJvcGRvd24gfSBmcm9tICdzZW1hbnRpYy11aS1yZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICcuLi9yb3V0ZXMnO1xyXG5pbXBvcnQgd2ViMyBmcm9tICcuLi9ldGhlcmV1bS93ZWIzJztcclxuaW1wb3J0IGNyeXB0b0J5dGU3MjEgZnJvbSAnLi4vZXRoZXJldW0vY3J5cHRvQnl0ZTcyMSc7XHJcblxyXG5sZXQgY3VycmVudEFjY291bnQ7XHJcblxyXG5jbGFzcyBIZWFkZXIgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gIHN0YXRlID0ge1xyXG4gICAgaXNBZG1pbjogJ25vbmUnLFxyXG4gICAgdmlzaWJsZUZ1bGw6ICdoaWRkZW4nLFxyXG4gICAgcGF1c2VkTW91bnRlZDogZmFsc2UsXHJcbiAgICBoYXNNb3VudGVkOiBmYWxzZSxcclxuICB9O1xyXG5cclxuICBhc3luYyBjb21wb25lbnREaWRNb3VudCgpIHtcclxuICAgIGN1cnJlbnRBY2NvdW50ID0gKGF3YWl0IHdlYjMuZXRoLmdldEFjY291bnRzKCkpWzBdO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgKGF3YWl0IHdlYjMuZXRoLm5ldC5nZXROZXR3b3JrVHlwZSgpKSA9PT0gcHJvY2Vzcy5lbnYuTkVUV09SS19UWVBFICYmXHJcbiAgICAgIHR5cGVvZiBjdXJyZW50QWNjb3VudCAhPT0gJ3VuZGVmaW5lZCdcclxuICAgICkge1xyXG4gICAgICBjb25zdCBpc01pbnRlciA9IGF3YWl0IGNyeXB0b0J5dGU3MjEubWV0aG9kc1xyXG4gICAgICAgIC5pc01pbnRlcihjdXJyZW50QWNjb3VudClcclxuICAgICAgICAuY2FsbCgpO1xyXG5cclxuICAgICAgaWYgKGlzTWludGVyKSB7XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGlzQWRtaW46ICdmbGV4JyB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICBpZiAoIXRoaXMuc3RhdGUuaGFzTW91bnRlZCAmJiB0aGlzLnByb3BzLm1vdW50ZWQgPT0gdHJ1ZSkge1xyXG4gICAgICAgIHRoaXMucHJvcHMudXBkYXRlU3RhdGUodHJ1ZSk7XHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IHZpc2libGVGdWxsOiAndmlzaWJsZScsIGhhc01vdW50ZWQ6IHRydWUgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0aGlzLnByb3BzLm1vdW50ZWQgPT0gZmFsc2UpIHtcclxuICAgICAgICB0aGlzLnByb3BzLnVwZGF0ZVN0YXRlKGZhbHNlKTtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgdmlzaWJsZUZ1bGw6ICdoaWRkZW4nIH0pO1xyXG4gICAgICB9XHJcbiAgICB9LCA1MDApO1xyXG4gIH1cclxuXHJcbiAgaGlkZUFsbCgpIHtcclxuICAgIHRoaXMuc2V0U3RhdGUoeyB2aXNpYmxlRnVsbDogJ2hpZGRlbicgfSk7XHJcbiAgICB0aGlzLnByb3BzLnVwZGF0ZVN0YXRlKGZhbHNlKTtcclxuICB9XHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPE1lbnVcclxuICAgICAgICAgIHN0YWNrYWJsZVxyXG4gICAgICAgICAgaW52ZXJ0ZWRcclxuICAgICAgICAgIGZpeGVkPVwidG9wXCJcclxuICAgICAgICAgIGlkPVwiaGVhZGVyXCJcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRoaXMuc3RhdGUudmlzaWJsZUZ1bGwsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCI+XHJcbiAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cIml0ZW1cIj5cclxuICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9zdGF0aWMvZmF2aWNvbjIucG5nXCIgLz5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9cIj5cclxuICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiaXRlbVwiPkhvbWU8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8RHJvcGRvd24gaXRlbSB0ZXh0PVwiQ29sbGVjdGlibGUgVG9rZW5zXCI+XHJcbiAgICAgICAgICAgIDxEcm9wZG93bi5NZW51PlxyXG4gICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvdG9rZW5zXCI+XHJcbiAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpdGVtXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKGxvY2F0aW9uLnBhdGhuYW1lID09ICcvdG9rZW5zJykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaGlkZUFsbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aGlzLmhpZGVBbGwoKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWxsIFRva2Vuc1xyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8TGluayBocmVmPXtgL3Rva2Vucy8ke2N1cnJlbnRBY2NvdW50fWB9PlxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaXRlbVwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmhpZGVBbGwoKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTXkgVG9rZW5zXHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvY3JlYXRlX3Rva2Vuc1wiPlxyXG4gICAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiaXRlbVwiPkNyZWF0ZSBOZXcgVG9rZW5zPC9hPlxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bi5NZW51PlxyXG4gICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvbWVkaWFcIj5cclxuICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiaXRlbVwiPk1lZGlhPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxNZW51Lk1lbnVcclxuICAgICAgICAgICAgcG9zaXRpb249XCJyaWdodFwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnIzQ0NDQ0NCcsXHJcbiAgICAgICAgICAgICAgZGlzcGxheTogdGhpcy5zdGF0ZS5pc0FkbWluLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8TGluayByb3V0ZT1cIi9cIj5cclxuICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJpdGVtXCI+QWRtaW4gUGFnZTwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9NZW51Lk1lbnU+XHJcbiAgICAgICAgPC9NZW51PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIZWFkZXI7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=